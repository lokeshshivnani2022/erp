<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Employees extends Migration
{
    public function up()
    {
    

        $this->dbforge->add_field(array(
            'id' => array(
                    'type' => 'BIGINTEGER',
                    'unsigned' => TRUE,
                    'auto_increment' => TRUE
            ),

            'full_name' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
               
             ),

            'designation' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'pay_band' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'level' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'ac_no' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'ifsc_code' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'bank_name' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'branch' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'addhar_no' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'pan_no' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'pic_no' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'bank_passbook' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),

            'pol_letter_no' => array(
                'type' => 'VARCHAR',
                'constraint' => '255',
            
            ),








            'email_id' => array(
                    'type' => 'VARCHAR',
                    'constraint' => '255',
            ),
            'password' => array(
                    'type' => 'VARCHAR',
                    'constraint' => '255',
                   
            ),
    ));
    $this->dbforge->add_key('id', TRUE);
    $this->dbforge->create_table('employees');

        
    }

    public function down()
    {
        //
    }
}
