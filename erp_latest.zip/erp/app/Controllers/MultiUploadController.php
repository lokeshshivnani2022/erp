<?php

namespace App\Controllers;

use \CodeIgniter\Controller;

class MultiUpload extends Controller{
    public function _contruct(){
        helper('form');
        
    }

}

?>