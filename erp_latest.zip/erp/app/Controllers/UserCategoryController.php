<?php

namespace App\Controllers;

use CodeIgniter\Controller;

use App\Models\UserCategoryModel;

class UserCategoryController extends Controller
{
    public function user_category_add(){

        $session= \Config\Services::session();
        helper('form');
        $data=[];

        $userCategoryModel=new UserCategoryModel();
        $data['user_categorys']=$userCategoryModel->findAll();
        if($this->request->getMethod()=='post')
        {
 
            $input=$this->validate([
                'title'=>'required|min_length[3]',
            ]);
            if($input == true){                
                //Form validate successfully,so we can save values to databases
                $model = new UserCategoryModel();
                $model->save([
                    'title'=>$this->request->getPost('title'),
                ]);
                $session->setFlashdata('success','Record added successfully.');
                return redirect()->to('/user_management/user_category/view');
            }
            else{
                //form not validated
                $data['validation']=$this->validator;
            }
        }

        return view('user_management/user_category/add');
    }

    public function user_category_view(){
        $model=new UserCategoryModel();
        $userCategoryArray=$model->getRecords();
        $data['userCategorys']=$userCategoryArray;

        return view('user_management/user_category/view',$data);
    }
    
    public function user_category_edit($id){
        $session= \Config\Services::session();
        helper('form');    
        $model = new UserCategoryModel();
        $user_category = $model->getRow($id);
        if(empty($user_category)){
            $session->setFlashdata('error','Record not found.');
            return redirect()->to('/user_management/user_category/view');
        }
        $data=[];
        $data['user_category']=$user_category;
        if($this->request->getMethod()=='post')
        {  
            $input=$this->validate([
                'title'=>'required|min_length[3]'
            ]);
            if($input == true){                
                //Form validate successfully,so we can save values to databases
                $model = new UserCategoryModel();
                $model->update($id,
                    ['title'=>$this->request->getPost('title')
                ]);
                $session->setFlashdata('success','Record updated successfully.');
                return redirect()->to('/user_management/user_category/view');
            }
            else{
                //form not validated
                $data['validation']=$this->validator;
            }
        }
        return view('user_management/user_category/edit',$data);
    }
    
    public function user_category_delete($id){
    
        $session= \Config\Services::session();    
        $model = new UserCategoryModel();
        $user_category = $model->getRow($id);
        if(empty($user_category)){
            $session->setFlashdata('error','Record not found.');
            return redirect()->to('/user_management/user_category/view');
        }
        $model= new UserCategoryModel();
        $model->delete($id);
        $session->setFlashdata('success','Record deleted successfully.');
        return redirect()->to('/user_management/user_category/view');
    
    }
}
