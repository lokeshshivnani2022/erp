<?php

namespace App\Controllers;

use \CodeIgniter\Controller;

class FileUploadController extends Controller{

    public function __construct(){
        helper('form');
    }

    public function index(){
        if($this-> request->getMethod()=='post'){
            $file = $this->request->getFile('avatar');
            if($file->isValid() && $file->hasMoved()){
                $file-> move($)
            }
        }
        return view ('upload_view');
    }
    
}

?>