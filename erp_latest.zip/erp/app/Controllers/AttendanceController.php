<?php

namespace App\Controllers;

use App\Controllers\BaseController;

use App\Models\AttendanceModel;
use App\Models\EmployeeModel;

class AttendanceController extends BaseController
{
    public function create(){
        $session= \Config\Services::session();
        helper('form');
        $data=[];

      
        if($this->request->getMethod()=='post')
        {
            //Form validate successfully,so we can save values to databases
            $model = new AttendanceModel();
            $emp_id=$this->request->getPost('emp_id');
            print_r($emp_id);
            foreach($emp_id as $employee)
           {

echo $employee;

            /*$emp_name=$this->request->getPost('emp_name['.$employee.']');*/
          echo   $attendance=$this->request->getPost('attendance['.$employee.']');
          echo   $remark=$this->request->getPost('remark['.$employee.']');
          echo  $attendance_date=$this->request->getPost('attendance_date');

            $model->save([
                'emp_id'=>$employee,
                
                'attendance'=>$attendance,
                'remark'=>$remark,
                'attendance_date'=>  $attendance_date             
            ]);
        }
            $session->setFlashdata('success','Record added successfully.');
           // return redirect()->to('/attendance/view');           
                        
        }
        return view('attendance/add',$data);
    }

    public function view()
    {
        $employeeModel=new EmployeeModel();
        $data['employees']=$employeeModel->findAll();

        
        return view('attendance/view',$data);
    }    
}