<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DepartmentModel;

class DepartmentController extends BaseController
{

public function create()
    {
        $session= \Config\Services::session();
        helper('form');
        $data=[];
        if($this->request->getMethod()=='post')
        {
 
            $input=$this->validate([
                'dep_name'=>'required|min_length[3]',
            ]);
            if($input == true){                
                //Form validate successfully,so we can save values to databases
                $model = new DepartmentModel();
                $model->save([
                    'dep_name'=>$this->request->getPost('dep_name'),
                ]);
                $session->setFlashdata('success','Record added successfully.');
                return redirect()->to('/department/view');
            }
            else{
                //form not validated
                $data['validation']=$this->validator;
            }
        }


        return view('department/add',$data);
    }
public function view(){
        $model=new DepartmentModel();
        $departmentArray=$model->getRecords();
        $data['departments']=$departmentArray;

        return view('department/view',$data);

}
public function edit($dep_id){
    $session= \Config\Services::session();
    helper('form');    
    $model = new DepartmentModel();
    $department = $model->getRow($dep_id);
    if(empty($department)){
        $session->setFlashdata('error','Record not found.');
        return redirect()->to('/department');
    }
    $data=[];
    $data['department']=$department;
    if($this->request->getMethod()=='post')
    {  
        $input=$this->validate([
            'dep_name'=>'required|min_length[3]'
        ]);
        if($input == true){                
            //Form validate successfully,so we can save values to databases
            $model = new DepartmentModel();
            $model->update($dep_id,
                ['dep_name'=>$this->request->getPost('dep_name')
            ]);
            $session->setFlashdata('success','Record updated successfully.');
            return redirect()->to('/department/view');
        }
        else{
            //form not validated
            $data['validation']=$this->validator;
        }
    }
    return view('department/edit',$data);
}

public function delete($dep_id){

    $session= \Config\Services::session();    
    $model = new departmentModel();
    $department = $model->getRow($dep_id);
    if(empty($department)){
        $session->setFlashdata('error','Record not found.');
        return redirect()->to('/department');
    }
    $model= new departmentModel();
    $model->delete($dep_id);
    $session->setFlashdata('success','Record deleted successfully.');
    return redirect()->to('/department/view');

    }
}

