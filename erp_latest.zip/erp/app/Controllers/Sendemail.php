<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use PHPUnit\Util\Xml\Validator;
use \Config\Services\session;

class Sendemail extends BaseController
{

    // public function __construct()
    // {
    //  helper(['form','url']);
    // }
    // public function contact()
    // {

    //    echo view('pages/header');
    //    echo view('contact');
    //    echo view('pages/footer'); 
    // }

    public function send()
    {

        $inputs=$this->validate([
                'email'=>[
                    
                'label'=>'Email',
                'rules' =>'required|valid_email',
                'errors'=>[
                    'required'=>'Please enter email',
                    'valid_email'=>'Please Enter valid email id '

                ]
                ],
                'subject'=>[
                    
                    'label'=>'Subject',
                    'rules' =>'required|min_length[5]',
                    'errors'=>[
                        'required'=>'Please enter subject',
                        'min_length'=>'Please enter at least 5 characters  '
    
                    ]
                ],

                    'message'=>[
                    
                        'label'=>'Message',
                        'rules' =>'required|min_length[10]',
                        'errors'=>[
                            'required'=>'Please enter message',
                            'min_length'=>'Please enter at least 10 characters  '
        
                        ]
                        ],

                        'phone'=>[
                    
                            'label'=>'Phone',
                            'rules' =>'required|min_length[10]|regex_match[/^[0-9]{10}$/]',
                            'errors'=>[
                                'required'=>'Please enter mobile number',
                                'egex_match'=>'Please enter 10 digit mobile number  '
            
                            ]

                            ],
                            'name'=>[
                    
                                'label'=>'name',
                                'rules' =>'required|min_length[3]',
                                'errors'=>[
                                    'required'=>'Please enter name',
                                    'min_length'=>'Please enter at least 3 characters  '
                
                                ]
    
                ]
         
        ]
        );
        if(!$inputs)
        {
            echo view('layouts/header');
            return view('employee/view',['validation'=>$this->validator] );
            echo view('layouts/footer');
           
        }
        else
        {
            $email= $this->request->getPost('email');
            $name=$this->request->getPost('name');
            $phone=$this->request->getPost('phone');
            $subject=$this->request->getPost('subject');
            $message=$this->request->getPost('message');
            $message='<table><tr><td><b>Name : </b></td><td>'.$name.'</td></tr>
                      <tr><td><b>Email : </b></td><td>'.$email.'</td></tr>
                      <tr><td><b>Phone : </b></td><td>'.$phone.'</td></tr>
                      <tr><td><b>Message : </b></td><td>'.$message.'</td></tr>
                       <tr><td><b>Sent From: </b></td><td>Cressid Educare Website</td></tr>
                      </table>';
                      
            $mail=\Config\Services::email();
            
            $mail->setFrom($email);
            $mail->setTo('info@cressidaeducare.com');
            $mail->setSubject($subject);
            $mail->setMessage($message);
            
            $cressida=$mail->send();
            
            $mail->setFrom('info@cressidaeducare.com');
            $mail->setTo($email);
            $subject='Do not reply';
            $mail->setSubject($subject);
            $message='<h1>Cressida Educare</h1><p>Thankyou to send your message we will reply you soon.</p>
            <img src="http://cressidaeducare.com/public/assets/images/logo/01.png">';
            $mail->setMessage($message);
            
            $user=$mail->send();
            
            
             $session=session();

            if($cressida)
            {
                $session->setFlashdata('success','Your message has been sent successfully');
            
                return redirect()->to(site_url('/contact'));
            }
            else
            {
                $session->setFlashdata('error','Sorry your message could not sent');   
                
                
                return redirect()->to(site_url('/contact'));
            }

        }

    
    
    
    }

}
