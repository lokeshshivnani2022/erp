<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\EmployeeModel;
use App\Models\DepartmentModel;
use App\Models\DesignationModel;

class EmployeeController extends BaseController
{
    
    public function create(){ 
        // for create a session
        $session= \Config\Services::session();
        helper('form');
        $data=[];

        $employeeModel=new EmployeeModel();
        $data['employees']=$employeeModel->findAll();
        $departmentModel=new DepartmentModel();
        $data['departments']=$departmentModel->findAll();
        if($this->request->getMethod()=='post')
        {
 
                $input=$this->validate([
                    'first_name'=>'required|min_length[3]', //validation in first_name
                    'middle_name'=>'required|min_length[3]',//validation in middle_name
                    'last_name'=>'required|min_length[3]'
                ]); 
                
                $data['validation']=$this->validator;                            
                //Form validate successfully,so we can save values to databases
                $image_upload_image = '';
                $productCategory = new EmployeeModel();

                $image = $this->request->getFile('upload_10th_marksheet');

                if (!empty($image) && $image->isValid() && !$image->hasMoved()) {

                $image_upload_image = $image->getRandomName();

                $image->move(FCPATH . 'public/10th/img/', $image_upload_image);
                }
                //$path= $file->store();
                $data = [
                    'first_name'=>$this->request->getPost('first_name'),
                    'middle_name'=>$this->request->getPost('middle_name'),
                    'last_name'=>$this->request->getPost('last_name'),
                    'dob'=>$this->request->getPost('dob'),
                    'gender'=>$this->request->getPost('gender'),
                    'father_name'=>$this->request->getPost('father_name'),
                    'mother_name'=>$this->request->getPost('mother_name'),
                    'email'=>$this->request->getPost('email'),
                    'city'=>$this->request->getPost('city'),
                    'state'=>$this->request->getPost('state'),
                    'country'=>$this->request->getPost('country'),
                    'department'=>$this->request->getPost('department'),
                    'designation'=>$this->request->getPost('designation'),
                    'zip_code'=>$this->request->getPost('zip_code'),
                    'current_address'=>$this->request->getPost('current_address'),
                    'permanent_address'=>$this->request->getPost('permanent_address'),
                    'mobile_number'=>$this->request->getPost('mobile_number'),
                    'alternate_mobile_number'=>$this->request->getPost('alternate_mobile_number'),
                    'bio'=>$this->request->getPost('bio'),
                    'job_title'=>$this->request->getPost('job_title'),
                    'company_name'=>$this->request->getPost('company_name'),
                    'job_start_date'=>$this->request->getPost('job_start_date'),
                    'job_end_date'=>$this->request->getPost('job_end_date'),
                    'job_role_experience_description'=>$this->request->getPost('job_role_experience_description'),
                    'marks_obtained_in_10th'=>$this->request->getPost('marks_obtained_in_10th'),
                    'upload_10th_marksheet'=>$image_upload_image,
                    'marks_obtained_in_12th'=>$this->request->getPost('marks_obtained_in_12th'),
                    'upload_12th_marksheet'=>$this->request->getPost('upload_12th_marksheet'),
                    'highest_qualification'=>$this->request->getPost('highest_qualification'),
                    'highest_marks'=>$this->request->getPost('highest_marks'),
                    'upload_marksheet'=>$this->request->getPost('upload_marksheet'),
                    'bank_name'=>$this->request->getPost('bank_name'),
                    'account_number'=>$this->request->getPost('account_number'),
                    'ifsc_code'=>$this->request->getPost('ifsc_code'),
                    'upload_bank_passbook'=>$this->request->getPost('upload_bank_passbook'),
                    'aadhar_number'=>$this->request->getPost('aadhar_number'),
                    'upload_front_side_of_aadhar_card'=>$this->request->getPost('upload_front_side_of_aadhar_card'),
                    'upload_back_side_of_aadhar_card'=>$this->request->getPost('upload_back_side_of_aadhar_card'),
                    'pan_number'=>$this->request->getPost('pan_number'),
                    'upload_pan_card_image'=>$this->request->getPost('upload_pan_card_image'),
                    'password'=>$this->request->getPost('password'),
                ];
                // print_r($data);
                $model = new EmployeeModel();
                $model->save($data);
                $email= $this->request->getPost('email');
                $name=$this->request->getPost('first_name');
                $phone=$this->request->getPost('mobile_number');
                $subject="login credential";
                $message=$this->request->getPost('password')." ".$this->request->getPost('email');
                $message='<table><tr><td><b>Name : </b></td><td>'.$name.'</td></tr>
                        <tr><td><b>Email : </b></td><td>'.$email.'</td></tr>
                        <tr><td><b>Phone : </b></td><td>'.$phone.'</td></tr>
                        <tr><td><b>Message : </b></td><td>'.$message.'</td></tr>
                        <tr><td><b>Sent From: </b></td><td>Cressid Educare Website</td></tr>
                        </table>';
                        
                $mail=\Config\Services::email();
        
                
                $mail->setFrom('info@cressidaeducare.com');
                $mail->setTo($email);
                $subject='Do not reply';
                $mail->setSubject($subject);
                $message='<h1>Cressida Educare</h1><p>Thankyou to send your message we will reply you soon.</p>
                <img src="http://cressidaeducare.com/public/assets/images/logo/01.png">';
                $mail->setMessage($message);
                
                $user=$mail->send();

                $session->setFlashdata('success','Record added successfully.');
                return redirect()->to('/employee/view');
        }
        return view('employee/add',$data);
    }

    public function view(){
        $model=new EmployeeModel();
        $employeeArray=$model->getRecords();
        $data['employees']=$employeeArray;
        $departmentModel=new DepartmentModel();
        $departmentArray=$departmentModel->getRecords();
        $data['departments']=$departmentArray;


        return view('employee/view',$data);

    }
    public function edit($id){
        $session= \Config\Services::session();
        helper('form');    
        $model = new EmployeeModel();
        $employee = $model->getRow($id);
        if(empty($employee)){
            $session->setFlashdata('error','Record not found.');
            return redirect()->to('/employee/view');
        }
        $data=[];
        $employeeModel=new EmployeeModel();
        $data['employees']=$employeeModel->findAll();   
        $data['employee']=$employee;
        if($this->request->getMethod()=='post')
        {  
            $input=$this->validate([
                'first_name'=>'required|min_length[3]'
            ]);
            if($input == true){
                $image = $this->request->getFile('upload_10th_marksheet');

                if (!empty($image) && $image->isValid() && !$image->hasMoved()) {

                $image_upload_image = $image->getRandomName();

                $image->move(FCPATH . 'public/10th/img/', $image_upload_image);


                $data = ['fisrt_name'=>$this->request->getPost('first_name'),
                        'middle_name'=>$this->request->getPost('middle_name'),
                        'last_name'=>$this->request->getPost('last_name'),
                        'dob'=>$this->request->getPost('dob'),
                        'gender'=>$this->request->getPost('gender'),
                        'father_name'=>$this->request->getPost('father_name'),
                        'mohter_name'=>$this->request->getPost('mohter_name'),
                        'email'=>$this->request->getPost('email'),
                        'city'=>$this->request->getPost('city'),
                        'state'=>$this->request->getPost('state'),
                        'country'=>$this->request->getPost('country'),
                        'department'=>$this->request->getPost('department'),
                        'designation'=>$this->request->getPost('designation'),
                        'zip_code'=>$this->request->getPost('zip_code'),
                        'current_address'=>$this->request->getPost('current_address'),
                        'permanent_address'=>$this->request->getPost('permanent_address'),
                        'mobile_number'=>$this->request->getPost('mobile_number'),
                        'alternate_mobile_number'=>$this->request->getPost('alternate_mobile_number'),
                        'bio'=>$this->request->getPost('bio'),
                        'job_title'=>$this->request->getPost('job_title'),
                        'company_name'=>$this->request->getPost('company_name'),
                        'job_start_date'=>$this->request->getPost('job_start_date'),
                        'job_end_date'=>$this->request->getPost('job_end_date'),
                        'job_role_experience_description'=>$this->request->getPost('job_role_experience_description'),
                        'marks_obtained_in_10th'=>$this->request->getPost('marks_obtained_in_10th'),
                        'upload_10th_marksheet'=>$image_upload_image,
                        'marks_obtained_in_12th'=>$this->request->getPost('marks_obtained_in_12th'),
                        'upload_12th_marksheet'=>$this->request->getPost('upload_12th_marksheet'),
                        'highest_qualification'=>$this->request->getPost('highest_qualification'),
                        'highest_marks'=>$this->request->getPost('highest_marks'),
                        'upload_marksheet'=>$this->request->getPost('upload_marksheet'),
                        'bank_name'=>$this->request->getPost('bank_name'),
                        'account_number'=>$this->request->getPost('account_number'),
                        'ifsc_code'=>$this->request->getPost('ifsc_code'),
                        'upload_bank_passbook'=>$this->request->getPost('upload_bank_passbook'),
                        'aadhar_number'=>$this->request->getPost('aadhar_number'),
                        'upload_front_side_of_aadhar_card'=>$this->request->getPost('upload_front_side_of_aadhar_card'),
                        'upload_back_side_of_aadhar_card'=>$this->request->getPost('upload_back_side_of_aadhar_card'),
                        'pan_number'=>$this->request->getPost('pan_number'),
                        'upload_pan_card_image'=>$this->request->getPost('upload_pan_card_image'),
                        'password'=>$this->request->getPost('password')
                    ];                    
                } else {
                $data = ['fisrt_name'=>$this->request->getPost('first_name'),
                        'middle_name'=>$this->request->getPost('middle_name'),
                        'last_name'=>$this->request->getPost('last_name'),
                        'dob'=>$this->request->getPost('dob'),
                        'gender'=>$this->request->getPost('gender'),
                        'father_name'=>$this->request->getPost('father_name'),
                        'mohter_name'=>$this->request->getPost('mohter_name'),
                        'email'=>$this->request->getPost('email'),
                        'city'=>$this->request->getPost('city'),
                        'state'=>$this->request->getPost('state'),
                        'country'=>$this->request->getPost('country'),
                        'department'=>$this->request->getPost('department'),
                        'designation'=>$this->request->getPost('designation'),
                        'zip_code'=>$this->request->getPost('zip_code'),
                        'current_address'=>$this->request->getPost('current_address'),
                        'permanent_address'=>$this->request->getPost('permanent_address'),
                        'mobile_number'=>$this->request->getPost('mobile_number'),
                        'alternate_mobile_number'=>$this->request->getPost('alternate_mobile_number'),
                        'bio'=>$this->request->getPost('bio'),
                        'job_title'=>$this->request->getPost('job_title'),
                        'company_name'=>$this->request->getPost('company_name'),
                        'job_start_date'=>$this->request->getPost('job_start_date'),
                        'job_end_date'=>$this->request->getPost('job_end_date'),
                        'job_role_experience_description'=>$this->request->getPost('job_role_experience_description'),
                        'marks_obtained_in_10th'=>$this->request->getPost('marks_obtained_in_10th'),
                        // 'upload_10th_marksheet'=>$this->request->getPost('upload_10th_marksheet'),
                        'marks_obtained_in_12th'=>$this->request->getPost('marks_obtained_in_12th'),
                        // 'upload_12th_marksheet'=>$this->request->getPost('upload_12th_marksheet'),
                        'highest_qualification'=>$this->request->getPost('highest_qualification'),
                        'highest_marks'=>$this->request->getPost('highest_marks'),
                        // 'upload_marksheet'=>$this->request->getPost('upload_marksheet'),
                        'bank_name'=>$this->request->getPost('bank_name'),
                        'account_number'=>$this->request->getPost('account_number'),
                        'ifsc_code'=>$this->request->getPost('ifsc_code'),
                        // 'upload_bank_passbook'=>$this->request->getPost('upload_bank_passbook'),
                        'aadhar_number'=>$this->request->getPost('aadhar_number'),
                        // 'upload_front_side_of_aadhar_card'=>$this->request->getPost('upload_front_side_of_aadhar_card'),
                        // 'upload_back_side_of_aadhar_card'=>$this->request->getPost('upload_back_side_of_aadhar_card'),
                        'pan_number'=>$this->request->getPost('pan_number'),
                        // 'upload_pan_card_image'=>$this->request->getPost('upload_pan_card_image'),
                        'password'=>$this->request->getPost('password')

                    ];
                }                
                //Form validate successfully,so we can save values to databases
                $model = new EmployeeModel();
                $model->update($id,$data);
                $session->setFlashdata('success','Record updated successfully.');
                return redirect()->to('/employee/view');
            }
            else{
                //form not validated
                $data['validation']=$this->validator;
            }
        }
        return view('employee/edit',$data);
    }
    public function delete($id){
        $session= \Config\Services::session();    
        $model = new EmployeeModel();
        $employee = $model->getRow($id);
            if(empty($employee)){
            $session->setFlashdata('error','Record not found.');
            return redirect()->to('/employee');
            }
        $model= new EmployeeModel();
        $model->delete($id);
        $session->setFlashdata('success','Record deleted successfully.');
        return redirect()->to('/employee/view');
    }
}
