<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class AdminController extends BaseController
{
    public function dashboard()
    {
        return view('profile/dashboard');
    }
    public function budget_revenues()
    {
        return view('accounting/budget_revenues');
    }
    public function budget_expenses()
    {
        return view('accounting/budget_expenses');
    }
    public function budgets(){
        return view('accounting/budgets');
    }
    public function categories()
    {
        return view('accounting/categories');
    }
    public function employee_salary(){
        return view('payroll/employee_salary');
    }
    public function pay_slip(){
        return view('payroll/pay_slip');
    }
    public function payroll_items(){
        return view('payroll/payroll_items');
    }
    public function sendemail(){
        $this->form_validation->set_rules('first_name','User Name','required|alpha');
        $this->form_validation->set_rules('password','Password','required|max_length[12]');
        $this->form_validation->set_rules('first_name','First Name','required|alpha');
        $this->form_validation->set_rules('last_name','last Name','required|alpha');
        $this->form_validation->set_rules('email','Email','required|valid_email|is_unique[employee.email]');
        $this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
        if($this->form_validation->run()){
            $this->load->library('email');
            $this->email->form(set_value('email'),set_value('fname'));
            $this->email->to("lokeshshivnani2022@gmail.com");
            $this->email->subject("Registration Greetings..");

            $this->email->message("Thankyou for registration");
            $this->email->set_newline("\r\n");
            $this->email->send();

            if(!$this->email->send()){
                show_error($this->email->print_debugger());
            }
            else{
                echo "your e-mail has been sent!";
            }
        }
        else{
            $this->load->view('employee/view');
        }
    }
}