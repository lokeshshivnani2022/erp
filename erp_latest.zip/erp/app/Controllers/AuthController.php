<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\EmployeeModel;

class AuthController extends BaseController
{
    public function login()
  {


    if ($this->request->getMethod() == 'post') {
      $check = $this->validate([

        "email" => "required|min_length[8]|valid_email",
        "password" => "required|min_length[8]",


      ]);

      if (!$check) {
        return view(
          'auth/login',
          [
            "title" => "Admin User Login",
            "validation" => $this->validator
          ]
        );
      } else {
        $adminModel = new EmployeeModel();

        $user =  $adminModel->where('email', $this->request->getVar('email'))->first();

        if ($user) {
          if (password_verify($this->request->getVar('password'), $user['password'])) {

            $user_data = [
              'admin_loggedin_email'  => $user['email'],
              'admin_first_name'     => $user['first_name'],
              'admin_middle_name'    => $user['middle_name'],
              'admin_last_name'     => $user['last_name'],
              //'admin_profile_image' => $user['profile_image'],
              'isLoggedIn' => true,

            ];

            session()->set($user_data);

            return redirect()->to(base_url('/dashboard'));
          } else {


            session()->setFlashdata('error', 'Invalid User Password');
          }
        } else {

          session()->setFlashdata('error', 'Invalid Email Id');
        }
      }
    }


    return view('auth/login');
  }
  public function logout()
  {
    $session = session();
    $session->destroy();
    return redirect()->to(base_url('/login'));
  }
    
    public function register()
    {
    if ($this->request->getMethod() == 'post') {
      $check = $this->validate([
        "first_name" => "required|min_length[3]|alpha",
        "middle_name" => "min_length[3]|alpha",
        "last_name" => "required|min_length[3]|alpha",
        "email" => "required|min_length[8]|valid_email|is_unique[employee.email]",
        "password" => "required|min_length[8]",
        "confirm_password" => "required|matches[password]"

      ]);

      if (!$check) {
        return view(
          'auth/register',
          [
            "title" => "employee User Sign up",
            "validation" => $this->validator
          ]
        );
      } else {
        $employeeModel = new EmployeeModel();

        $data = [
          "first_name" => $this->request->getVar('first_name'),
          "middle_name" => $this->request->getVar('middle_name'),
          "last_name" => $this->request->getVar('last_name'),
          "email" => $this->request->getVar('email'),
          "password" => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
        ];

        if ($employeeModel->save($data)) {

          session()->setFlashdata('success', 'employee User has been registered successfully');
          return redirect()->to(base_url() . '/login');
        }
      }
    }


    return view('auth/register');
  }
}
