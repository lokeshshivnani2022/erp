<?php

namespace App\Controllers;

use App\CodeIgniter\Controller;

use App\Models\OperationsListModel;
use App\Models\UserCategoryModel;

class OperationsListController extends BaseController
{
    public function operations_list_add(){
        $session= \Config\Services::session();
        helper('form');
        $data=[];

        $userCategoryModel=new UserCategoryModel();
        $data['user_categorys']=$userCategoryModel->findAll();

        if($this->request->getMethod()=='post')
        {
            //Form validate successfully,so we can save values to databases
            $model = new OperationsListModel();

            $operation=$this->request->getPost('operation');
            $read=$this->request->getPost('read');
            $write=$this->request->getPost('write');
            $update=$this->request->getPost('update');
            $delete=$this->request->getPost('delete');
            //to set bydefault off check box
            if(empty($this->request->getPost('operation')))
            {
                $operation='off';
            }
            if(empty($this->request->getPost('read')))
            {
                $read='off';
            }
            if(empty($this->request->getPost('write')))
            {
                $write='off';
            }
            if(empty($this->request->getPost('update')))
            {
                $update='off';
            }
            if(empty($this->request->getPost('delete')))
            {
                $delete='off';
            }
            $model->save([
                'user_category'=>$this->request->getPost('user_category'),
                'operation'=>$this->request->getPost('operation'),
                'read'=>$this->request->getPost('read'),
                'write'=>$this->request->getPost('write'),
                'update'=>$this->request->getPost('update'),
                'delete'=>$this->request->getPost('delete')
            ]);
            $session->setFlashdata('success','Record added successfully.');
            return redirect()->to('/user_management/operations_list/view');           
                        
        }
        return view('user_management/operations_list/add',$data);
    }

    public function operations_list_view(){
        $model=new OperationsListModel();
        $OperationslistArray=$model->getRecords();
        $data['operations_lists']=$OperationslistArray;
        $userCategoryModel=new UserCategoryModel();
        $data['user_categorys']=$userCategoryModel->findAll();
        return view('user_management/operations_list/view',$data);
    }
    
    public function operations_list_edit($id){
        $session= \Config\Services::session();
        helper('form');    
        $model = new OperationsListModel();
        $operations_list = $model->getRow($id);
        $userCategoryModel=new UserCategoryModel();
        $data['user_categorys']=$userCategoryModel->findAll();
        
        if(empty($operations_list)){
            $session->setFlashdata('error','Record not found.');
            return redirect()->to('/user_management/operations_list/view');
        }
        $data['operations_lists']=$operations_list;
        if($this->request->getMethod()=='post')
        {  
            $input=$this->validate([
                'title'=>'required|min_length[3]'
            ]);
            if($input == true){                
                //Form validate successfully,so we can save values to databases
                $model = new OperationsListModel();
                $model->update($id,
                    ['title'=>$this->request->getPost('title')
                ]);
                $session->setFlashdata('success','Record updated successfully.');
                return redirect()->to('/user_management/operations_list/view');
            }
            else{
                //form not validated
                $data['validation']=$this->validator;
            }
        }
        return view('user_management/operations_list/edit',$data);
    }
    
    public function operations_list_delete($id){
    
        $session= \Config\Services::session();    
        $model = new OperationsListModel();
        $operations_list = $model->getRow($id);
        if(empty($operations_list)){
            $session->setFlashdata('error','Record not found.');
            return redirect()->to('/user_management/operations_list/view');
        }
        $model= new OperationsListModel();
        $model->delete($id);
        $session->setFlashdata('success','Record deleted successfully.');
        return redirect()->to('/user_management/operations_list/view');
    
    }
}
