<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\DesignationModel;
use App\Models\DepartmentModel;
class DesignationController extends BaseController
{

public function create()
    {
        $session= \Config\Services::session();
        helper('form');
        $data=[];

        $departmentModel=new DepartmentModel();
        $data['departments']=$departmentModel->findAll();
        if($this->request->getMethod()=='post')
        { 
            $input=$this->validate([
                'deg_name'=>'required|min_length[3]'
            ]);
            if($input == true){                
                //Form validate successfully,so we can save values to databases
                $model = new DesignationModel();
                $model->save([
                    'deg_name'=>$this->request->getPost('deg_name'),
                    'dep_id'=>$this->request->getPost('dep_id')
                ]);
                $session->setFlashdata('success','Record added successfully.');
                return redirect()->to('/designation/view');
            }
            else{
                //form not validated
                $data['validation']=$this->validator;
            }
        }


        return view('designation/add',$data);
    }
public function view(){
        $model=new DesignationModel();
        $designationArray=$model->getRecords();
        $data['designations']=$designationArray;

        return view('designation/view',$data);

}
public function edit($deg_id){
    $session= \Config\Services::session();
    helper('form');    
    $model = new DesignationModel();
    $designation = $model->getRow($deg_id);
    if(empty($designation)){
        $session->setFlashdata('error','Record not found.');
        return redirect()->to('/designation/view');
    }
    $data=[];
    $departmentModel=new DepartmentModel();
    $data['departments']=$departmentModel->findAll();
    $data['designation']=$designation;
    if($this->request->getMethod()=='post')
    {  
        $input=$this->validate([
            'deg_name'=>'required|min_length[3]'
        ]);
        if($input == true){                
            //Form validate successfully,so we can save values to databases
            $model = new DesignationModel();
            $model->update($deg_id,
                ['deg_name'=>$this->request->getPost('deg_name'),
                'dep_id'=>$this->request->getPost('dep_id')
            ]);
            $session->setFlashdata('success','Record updated successfully.');
            return redirect()->to('/designation/view');
        }
        else{
            //form not validated
            $data['validation']=$this->validator;
        }
    }
    return view('designation/edit',$data);
}

public function delete($dep_id){

    $session= \Config\Services::session();    
    $model = new designationModel();
    $designation = $model->getRow($dep_id);
    if(empty($designation)){
        $session->setFlashdata('error','Record not found.');
        return redirect()->to('/designation');
    }
    $model= new designationModel();
    $model->delete($dep_id);
    $session->setFlashdata('success','Record deleted successfully.');
    return redirect()->to('/designation/view');
    }
}

