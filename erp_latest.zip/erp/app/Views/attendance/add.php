<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-lg-6 col-xl-6">
                    <h3 class="page-title">Daily Report</h3>
                    <ul class="breadcrumb">
                    <li class="breadcrumb-item">Attandence</li>
                    <li class="breadcrumb-item active">Add Attandence</li>
                    </ul>
                    </div>
                </div>
            </div>
            <div class="row" style="margin-right: 0px;">
                <div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="<?php echo base_url('attendance/add');?>" method="post">
                                <div class="row">                                
                                <div class="form-group col-md-6 col-sm-12 col-lg-6 col-xl-6">
                                    <label>Employee ID</label>
                                    <input class="form-control" placeholder="Enter Employee Id" type="text" name="emp_id">
                                    <?php
                                        if(isset($validation) && $validation->hasError('emp_id'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('emp_id').'</p>';
                                        }
                                    ?>
                                </div>
                                <div class="form-group col-md-6 col-sm-12 col-lg-6 col-xl-6">
                                    <label>Employee Name</label>
                                    <input class="form-control" placeholder="Enter Employee Name" type="text" name="emp_name">
                                    <?php
                                        if(isset($validation) && $validation->hasError('emp_name'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('emp_name').'</p>';
                                        }
                                    ?>
                                </div>
                                <div class="form-group col-md-6 col-sm-12 col-lg-6 col-xl-6">
                                    <label>Attendance</label>
                                    <select class="form-select" aria-label="Default select example" name="attendance">
                                            <option selected>Select</option>                                            
                                            <option value="1">Present</option>
                                            <option value="2">Absent</option>
                                            <option value="3">Leave</option>
                                            </select>
                                </div>
                                <div class="form-group col-md-6 col-sm-12 col-lg-6 col-xl-6">
                                    <label>Remark</label>
                                    <input class="form-control <?php echo (isset($validation) && $validation->hasError('remark')) ? 'is-invalid' : '';?>" placeholder="Enter Remark" value="<?php echo set_value('remark');?>" type="text" name="remark">
                                    <?php
                                        if(isset($validation) && $validation->hasError('remark'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('remark').'</p>';
                                        }
                                    ?>
                                </div>
                                <div class="form-group col-md-6 col-sm-12 col-lg-6 col-xl-6">
                                    <label>Attendance Date</label>
                                    <input type="date" class="form-control" value="" name="attendance_date">
                                </div>

                                
                                <div class="form-group text-end">
                                    <button class="btn btn-primary account-btn" type="submit">Submit</button>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>               

<?=$this->endSection()?>