<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">

            <div class="content container-fluid">

                <div class="page-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="page-title">Daily Report</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Attandence</a></li>
                                <li class="breadcrumb-item active">Daily Report</li>
                            </ul>
                        </div>
                        <div class="col-auto">
                            <!-- <a href="#" class="btn btn-primary">PDF</a> -->
                            <h5 class="page-title">Attendance Date:</h5>
                            <?php 
                            $currentDate = date('d-m-Y');
                            echo "<ul class='breadcrumb'> <li class='text-black'>".$currentDate."</li></ul>";
                            ?>
                        </div>
                    </div>
                </div>
                

                <div class="row justify-content-center">
                    <div class="col-md-3 col-sm-6">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3><b>101</b></h3>
                                <p>Total Employees</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-success"><b>84</b></h3>
                                <p>Today Present</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3 class="text-danger"><b>12</b></h3>
                                <p>Today Absent</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-6">
                        <div class="card">
                            <div class="card-body text-center">
                                <h3><b>5</b></h3>
                                <p>Today Left</p>
                            </div>
                        </div>
                    </div>
                </div>                
                <?php $session=session();
                if(!empty($session->getFlashdata('success')))
                {
                    ?>
                    <div class="alert alert-success">
                    <?php echo $session->getFlashdata('success');?>                    
                    </div>
                    <?php
                }
                ?>
                <?php
                if(!empty($session->getFlashdata('error')))
                {
                    ?>
                    <div class="alert alert-danger">
                    <?php echo $session->getFlashdata('error');?>                    
                    </div>
                    <?php
                }
                ?>

                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <form action="<?php echo base_url('attendance/add');?>" method="post">
                            <table class="table table-striped custom-table mb-0 datatable">
                                <thead>
                                    <tr>
                                        <th>Employee ID</th>
                                        <th>Employee Name</th>
                                        <th>Attandence</th>
                                        <th>Remark</th>
                                        <!-- <th>Attandence Date</th>
                                        <th class="text-center">Status</th> -->
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <?php if(!empty($employees)){ 
                                    foreach($employees as $attendance) 
                                    {
                                    ?>
                                    <tr>
                                        <td>
                                            <input type="text" name="emp_id[]" class="form-control" 
                                           value=" <?php echo $attendance['id'];?>" readonly>
                                        </td>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img src="<?=base_url('public/assets/img/profiles/avatar-02.jpg')?>" alt=""></a>
                                                <a href="#"><?php echo $attendance['first_name'];?></a>
                                            </h2>
                                        </td>
                                        <td>
                                            <select class="form-select" style="width:59%;" aria-label="Default select example" name="attendance[<?= $attendance['id']?>]">
                                            <option selected>Select</option>
                                            
                                            <option value="1">Present</option>
                                            <option value="2">Absent</option>
                                            <option value="3">Leave</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" style="width:60%" value="" name="remark[<?= $attendance['id']?>]" >
                                        </td>
                                        
                                    </tr>
                                    <?php }
                                    }
                                    else { ?>
                                        <tr colspan="5">Record not Found
                                    <?php } ?>
                                    <!-- <tr>
                                        <td>
                                            <span>#0002</span>
                                        </td>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img src="<?=base_url('public/assets/img/profiles/avatar-09.jpg')?>" alt=""></a>
                                                <a href="#"> Richard Miles</a>
                                            </h2>
                                        </td>
                                        <td>
                                            <select class="form-select" style="width:59%;" aria-label="Default select example">
                                            <option selected>Select</option>
                                            <option value="1">Present</option>
                                            <option value="2">Absent</option>
                                            <option value="3">Leave</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" style="width:60%" value="" name="bio">
                                        </td>
                                        
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>#0003</span>
                                        </td>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img src="<?=base_url('public/assets/img/profiles/avatar-10.jpg')?>" alt=""></a>
                                                <a href="#">John Smith</a>
                                            </h2>
                                        </td>
                                        <td>
                                            <select class="form-select" style="width:59%;" aria-label="Default select example">
                                            <option selected>Select</option>
                                            <option value="1">Present</option>
                                            <option value="2">Absent</option>
                                            <option value="3">Leave</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" style="width:60%" value="" name="bio">
                                        </td>
                                        
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>#0004</span>
                                        </td>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img src="<?=base_url('public/assets/img/profiles/avatar-05.jpg')?>" alt=""></a>
                                                <a href="#">Mike Litorus</a>
                                            </h2>
                                        </td>
                                        <td>
                                            <select class="form-select" style="width:59%;" aria-label="Default select example">
                                            <option selected>Select</option>
                                            <option value="1">Present</option>
                                            <option value="2">Absent</option>
                                            <option value="3">Leave</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" style="width:60%" value="" name="bio">
                                        </td>
                                        
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>#0001</span>
                                        </td>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img src="<?=base_url('public/assets/img/profiles/avatar-11.jpg')?>" alt=""></a>
                                                <a href="#">John Doe</a>
                                            </h2>
                                        </td>
                                        <td>
                                            <select class="form-select" style="width:59%;" aria-label="Default select example">
                                            <option selected>Select</option>
                                            <option value="1">Present</option>
                                            <option value="2">Absent</option>
                                            <option value="3">Leave</option>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" style="width:60%" value="" name="bio">
                                        </td>
                                        
                                    </tr>                                        -->
                                </tbody>
                            </table>
                            <div class="row float-end mt-3">
                                <button class="btn btn-primary account-btn" type="submit">Submit</button>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>

                

                
            </div>

        </div>


<?=$this->endSection()?>