<?php $this->extend('layouts/weblayout');?>



<?php $this->section('body');?>




<div class="container">
<div class="main-wrapper">
        <div class="account-content">
            <div class="container">

                <div class="account-logo">
                    <a href="#"><img src="<?=base_url('public/assets/img/logo2.png')?>" alt=""></a>
                </div>

                <div class="account-box">
                    <div class="account-wrapper">
                        <h3 class="account-title">Login</h3>
                        <p class="account-subtitle">Access to our dashboard</p>
                        <?php if(isset($validation)):?>
                            

                            <div class="alert alert-danger">

                          <?=$validation->listErrors();?>
                    
                        </div>
                       

                          <?php endif;
                          if(session()->getFlashdata('success')) :?>

                            <div class="alert alert-success">

                            <?=session()->getFlashdata('success')?>
                           </div>
                         <?php endif;

                          if(session()->getFlashdata('error')) :?>

                            <div class="alert alert-danger">

                            <?=session()->getFlashdata('error')?>
                           </div>
                         <?php endif;?>
                        <form action="<?=base_url('login')?>" method="post">
                            <!-- <div class="form-group">
                                <label>Employee ID</label>
                                <input class="form-control" type="text"  >
                            </div>                             -->
                            <div class="form-group">
                                <label>Email Address</label>
                                <input class="form-control" type="text" name="email">
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" type="text" name="password">
                            </div>
                           
                            <div class="form-group text-center">
                                <a href="testd.html">
                                    <button class="btn btn-primary account-btn" type="submit">Login</button>
                                </a>
                            </div>
                            <div class="account-footer">
                                <p>Don't have an account yet? <a href="test1.html">Register</a></p>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $this->endSection();?>