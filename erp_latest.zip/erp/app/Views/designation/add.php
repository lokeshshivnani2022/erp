<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">

    <div class="content container-fluid">

        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="page-title">Designation</h3>
                    <ul class="breadcrumb">
                    <li class="breadcrumb-item active">Add New Designation</li>
                    </ul>
                </div>
            </div>
        </div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-lg-6 col-xl-6">
            <div class="card">
                <div class="card-body">

                    <form action="<?=base_url('designation/add')?>" method="post">
                    <div class="form-group">
                    <label>Department</label>
                        <select name="dep_id" class="form-control">
                            <?php 
                            foreach($departments as $department)
                            echo "<option value='".$department['dep_id']."'>".$department['dep_name']."</option>";
                            ?>                      
                        </select> 
                    </div>
                                                                    
                    <div class="form-group">

                        <label>Designation</label>
                        <input class="form-control <?php echo (isset($validation) && $validation->hasError('dep_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('deg_name');?> " type="text" name="deg_name">
                        <?php
                            if(isset($validation) && $validation->hasError('deg_name'))
                            {
                                echo '<p class="invalid-feedback">'.$validation->getError('deg_name').'</p>';
                            }
                        ?>
                    </div>
                    <div class="form-group text-center">
                            <button class="btn btn-primary account-btn" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?=$this->endSection()?>