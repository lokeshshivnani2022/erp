<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">

<div class="content container-fluid">

<div class="page-header">
<div class="row">
<div class="col-sm-12">
<h3 class="page-title">Designation</h3>
<ul class="breadcrumb">
<li class="breadcrumb-item active">Update</li>
</ul>
</div>
</div>
</div>

<div class="row">
<div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
<div class="card">
<div class="card-body">

                        <form name="createForm" id="createForm" method="post" action="<?php echo base_url('designation/edit/'.$designation['deg_id']);?>">
                        <div class="form-group">
                        <label>Department</label>
                            <select name="dep_id" class="form-control">

<?php 
foreach($departments as $department)
if($department['dep_id']==$designation['dep_id'])
{
echo "<option value='".$department['dep_id']."' selected>".$department['dep_name']."</option>";
}
else{
    echo "<option value='".$department['dep_id']."'>".$department['dep_name']."</option>";
}
 ?>                      
 </select> </div>

                            <div class="form-group">
                                <label>Designation Name</label>
                                <input type="text" placeholder="Enter Designation" name="deg_name" id="deg_name" class="form-control <?php echo (isset($validation) && $validation->hasError('deg_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('deg_name',$designation['deg_name']);?>">
                                <?php
                                    if(isset($validation) && $validation->hasError('deg_name'))
                                    {
                                        echo '<p class="invalid-feedback">'.$validation->getError('deg_name').'</p>';
                                    }
                                ?>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">update</button>
                        </form>
                    </div>
                </div>
</div>
</div>
</div>
</div>
</div>
</div>

<?=$this->endSection()?>