<div class="sidebar" id="sidebar">
<div class="sidebar-inner slimscroll">
<div id="sidebar-menu" class="sidebar-menu">
<nav class="greedys sidebar-horizantal">
<ul class="list-inline-item list-unstyled links">
<li class="menu-title">
<span>Main</span>
</li>

<li class="submenu">
<a href="#"><i class="la la-dashboard"></i> <span> Dashboard</span> <span class="menu-arrow"></span></a>
<ul style="display: none;">
<li><a href="admin-dashboard.html">Admin Dashboard</a></li>
<li><a href="employee-dashboard.html">Employee Dashboard</a></li>
</ul>
</li>





<li class="submenu">
<a href="#"><i class="la la-dashboard"></i> <span>Accounting </span> <span class="menu-arrow"></span></a>
<ul style="display: none;">
<li><a href="<?=base_url('/accounting/budget_revenues')?>">Budget Revenue</a></li>
<li><a href="employee-dashboard.html">Employee Dashboard</a></li>
</ul>
</li>

</ul>
</div>
</div>
</div>