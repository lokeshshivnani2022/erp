<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <title>Login - HRMS admin template</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <meta name="description" content="Smarthr - PHP Admin Template">
    <meta name="keywords"
        content="admin, estimates, bootstrap, business, corporate, creative, management, minimal, modern, accounts, invoice, html5, responsive, CRM, Projects">
    <meta name="author" content="Dreamguys - PHP Admin Template">
    <meta name="robots" content="noindex, nofollow">

    <link rel="shortcut icon" href="<?=base_url('public/assets/img/favicon.png')?>">

    <link rel="stylesheet" href="<?=base_url('public/assets/css/bootstrap.min.css')?>">

    <link rel="stylesheet" href="<?=base_url('public/assets/plugins/fontawesome/css/fontawesome.min.css')?>">
    <link rel="stylesheet" href="<?=base_url('public/assets/plugins/fontawesome/css/all.min.css')?>">

    <link rel="stylesheet" href="<?=base_url('public/assets/css/line-awesome.min.css')?>">
    <link rel="stylesheet" href="<?=base_url('public/assets/css/material.css')?>">

    <link rel="stylesheet" href="<?=base_url('public/assets/css/font-awesome.min.css')?>">

    <link rel="stylesheet" href="<?=base_url('public/assets/css/style.css')?>">
</head>

<body class="account-page">



<?=$this->renderSection('body')?>


<script src="<?=base_url('public/assets/js/jquery-3.6.1.min.js')?>"></script>

    <script src="<?=base_url('public/assets/js/bootstrap.bundle.min.js')?>"></script>

    <script src="<?=base_url('public/assets/js/layout.js')?>"></script>
    <script src="<?=base_url('public/assets/js/theme-settings.js')?>"></script>
    <script src="<?=base_url('public/assets/js/greedynav.js')?>"></script>

    <script src="<?=base_url('public/assets/js/jquery.slimscroll.min.js')?>"></script>

    <script src="<?=base_url('public/assets/js/app.js')?>"></script>
</body>

</html>