<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Uploading</title>
</head>
<body>
    <h1>File Uploading</h1>
    <?= form_open_multipart(); ?>
        Upload Avatar: <input type='file' name='avatar'>
        <input type='submit' value='Upload'> 
    <?= form_close(); ?>
    
</body>
</html>