<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">

<div class="content container-fluid">

<div class="page-header">
<div class="row">
<div class="col-sm-12">
<h3 class="page-title">Department</h3>
<ul class="breadcrumb">
<li class="breadcrumb-item active">Update</li>
</ul>
</div>
</div>
</div>

<div class="row">
<div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
<div class="card">
<div class="card-body">

                        <form name="createForm" id="createForm" method="post" action="<?php echo base_url('department/edit/'.$department['dep_id']);?>">
                            <div class="form-group">
                                <label>Department Name</label>
                                <input type="text" placeholder="Enter Name" name="dep_name" id="dep_name" class="form-control <?php echo (isset($validation) && $validation->hasError('dep_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('dep_name',$department['dep_name']);?>">
                                <?php
                                    if(isset($validation) && $validation->hasError('dep_name'))
                                    {
                                        echo '<p class="invalid-feedback">'.$validation->getError('dep_name').'</p>';
                                    }
                                ?>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">update</button>
                        </form>
                    </div>
                </div>
</div>
</div>
</div>
</div>
</div>
</div>

<?=$this->endSection()?>