<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">

    <div class="content container-fluid">

        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Department</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Department</a></li>
                        <li class="breadcrumb-item active">View</li>
                    </ul>
                </div>
                <div class="col-auto float-end ms-auto">
                    <a href="<?php echo base_url('department/add/');?>" class="btn add-btn"><i
                    class="fa fa-plus"></i> Add Department</a>
                </div>
                </div>                
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
                <?php $session=session();
                if(!empty($session->getFlashdata('success')))
                {
                    ?>
                    <div class="alert alert-success">
                    <?php echo $session->getFlashdata('success');?>                    
                    </div>
                    <?php
                }
                ?>
                <?php
                if(!empty($session->getFlashdata('error')))
                {
                    ?>
                    <div class="alert alert-danger">
                    <?php echo $session->getFlashdata('error');?>                    
                    </div>
                    <?php
                }
                ?>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped custom-table mb-0 ">
                            <thead>
                                <tr>
                                    <th>DEPARTMENT NAME</th> 
                                   
                                    <th class="text-end" >Action</th>                            
                                </tr>
                            </thead>
                            <?php if(!empty($departments)){ 
                                foreach($departments as $department) {
                            ?>
                            <tr>                            
                                <td><?php echo $department['dep_name'];?></td>
                               <!-- <td>
                                    <a href="<?php echo base_url('department/edit/'.$department['dep_id']);?>" class="btn btn-primary btn-sm">Edit</a>
                                    <a  href="<?php echo base_url('department/delete/'.$department['dep_id']);?>" class="btn btn-danger btn-sm">Delete</a>
                                </td>-->
                                <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="<?php echo base_url('department/edit/'.$department['dep_id']);?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                                    <a class="dropdown-item" onclick="deleteConfirm(<?php echo $department['dep_id']?>);" href="<?php echo base_url('department/delete/'.$department['dep_id']);?>"> <i class="fa fa-trash m-r-5"></i> Delete </a>                                                    
                                                </div>
                                            </div>
                                        </td>
                            </tr>    
                            <?php }
                            }
                            else { ?> 
                                <tr colspan="5">Records not found
                            <?php }?>                
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?=$this->endSection()?>
<script>
   function deleteConfirm(dep_id){    
        if (confirm("are you sure you want to delete?")) {
            window.location.href='<?php echo base_url('department/delete/')?>/'+dep_id;     
        }
    }
</script>