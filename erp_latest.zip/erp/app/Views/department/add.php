<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-lg-6 col-xl-6">
                    <h3 class="page-title">Department</h3>
                    <ul class="breadcrumb">
                    <li class="breadcrumb-item active">Add New</li>
                    </ul>
                    </div>
                        </div>
                            </div>
                                <div class="row">
                                    <div class="col-md-12 col-sm-12 col-lg-6 col-xl-6">
                                        <div class="card">
                                            <div class="card-body">

                                                <form action="<?=base_url('department/add')?>" method="post">
                                                    <!-- <div class="form-group">
                                                        <label>Employee ID</label>
                                                        <input class="form-control" type="text"  >
                                                    </div>                             -->
                                                    <div class="form-group">
                                                        <label>Department</label>
                                                        <input class="form-control <?php echo (isset($validation) && $validation->hasError('dep_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('dep_name');?>" type="text" name="dep_name">
                                                        <?php
                                                            if(isset($validation) && $validation->hasError('dep_name'))
                                                            {
                                                                echo '<p class="invalid-feedback">'.$validation->getError('dep_name').'</p>';
                                                            }
                                                        ?>
                                                    </div>
                                                    <div class="form-group text-end">
                                                            <button class="btn btn-primary account-btn" type="submit">Submit</button>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?=$this->endSection()?>