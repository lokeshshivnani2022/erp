
<div class="row">
    <div class="col-md-6 mb-3">
        <label for="" class="form-label">Marks Obtained in 10th(%) </label>
        <input type="text" class="form-control"
            placeholder="Enter % obtained in 10th" wire:model="marks_10th">
    </div>
    <div class="col-md-6 mb-3">
        <label for="" class="form-label">Upload 10th Marksheet </label>
        <input type="file" class="form-control" wire:model="marksheet_10th">                                        
    </div>

    <div class="col-md-6 mb-3">
        <label for="" class="form-label">Marks Obtained in 12th(%) </label>
        <input type="text" class="form-control"
            placeholder="Enter % obtained in 12th" wire:model="marks_12th">
    </div>
    <div class="col-md-6 mb-3">
        <label for="" class="form-label">Upload 12th Marksheet </label>
        <input type="file" class="form-control" wire:model="marksheet_12th">
    </div>
    <div class="col-md-4 mb-3">
        <label for="" class="form-label">Highest Qualification </label>
        <select class="form-control" wire:model="highest_qualification">
            <option>Graduation</option>
            <option>Postgraduation</option>
            <option>Phd</option>
            <option>Other</option>
        </select>
    </div>
    <div class="col-md-4 mb-3">
        <label for="" class="form-label">Highest Marks</label>
        <input type="text" class="form-control" wire:model="marks_highest_degree"
            placeholder="Enter % Obtained">
    </div>
    <div class="col-md-4 mb-3">
        <label for="" class="form-label">Upload Marksheet</label>
        <input type="file" class="form-control"
            wire:model="marksheet_highest_degree">
    </div>
</div>                                    
  