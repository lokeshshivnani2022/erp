<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper" style="margin-left: 254px;">

    <div class="content container-fluid">

        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">User Management</h3>
                    <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Operation List</a></li>
                    <li class="breadcrumb-item active">View</li>
                    </ul>
                </div>
                <div class="col-auto float-end ms-auto">
                    <a href="<?php echo base_url('user_management/operations_list/add/');?>" class="btn add-btn"><i
                    class="fa fa-plus"></i> Add Operation</a>
                </div>
                </div>                
            </div>
        </div>
        <div class="row" style="margin-right: 0px;">
            <div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
                <?php $session=session();
                if(!empty($session->getFlashdata('success')))
                {
                    ?>
                    <div class="alert alert-success">
                    <?php echo $session->getFlashdata('success');?>                    
                    </div>
                    <?php
                }
                ?>
                <?php
                if(!empty($session->getFlashdata('error')))
                {
                    ?>
                    <div class="alert alert-danger">
                    <?php echo $session->getFlashdata('error');?>                    
                    </div>
                    <?php
                }
                ?>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped custom-table mb-2">
                            <thead>
                                <tr>
                                    <th>USER CATEGORY</th> 
                                    <th>OPERATION</th> 
                                    <th>READ</th> 
                                    <th>WRITE</th> 
                                    <th>UPDATE</th> 
                                    <th>DELETE</th>                                    
                                    <th class="text-end" >Action</th>                            
                                </tr>
                            </thead>
                            <?php if(!empty($operations_lists)){ 
                            foreach($operations_lists as $operations_list) {
                            ?>
                            <tr>                            
                                <?php 
                                // if ($user_category['id']==$operations_lists['user_category'])
                                // {
                                //     echo "<td>".$user_category['title']."</td>";
                                // }                                
                                ?>
                                                        
                                <td><?php echo $operations_list['operation'];?></td>                               
                                <td><?php echo $operations_list['read'];?></td>                               
                                <td><?php echo $operations_list['write'];?></td>                               
                                <td><?php echo $operations_list['update'];?></td>                               
                                <td><?php echo $operations_list['delete'];?></td>                               
                                <td class="text-end">
                                    <div class="dropdown dropdown-action">
                                        <a href="#" class="action-icon dropdown-toggle"
                                            data-bs-toggle="dropdown" aria-expanded="false"><i
                                                class="material-icons">more_vert</i></a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a class="dropdown-item" href="<?php echo base_url('user_management/operations_list/edit/'.$operations_list['id']);?>"><i class="fa fa-pencil m-r-5"></i> Edit</a>
                                            <a class="dropdown-item" onclick="deleteConfirm(<?php echo $operations_list['id']?>);" href="<?php echo base_url('user_management/operations_list/delete/'.$operations_list['id']);?>"> <i class="fa fa-trash m-r-5"></i> Delete </a>                                                    
                                        </div>
                                    </div>
                                </td>
                            </tr>    
                            <?php }
                            }
                            else { ?> 
                                <tr colspan="5">Records not found
                            <?php }?>                
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?=$this->endSection()?>
<script>
   function deleteConfirm(user_category){    
        if (confirm("are you sure you want to delete?")) {
            window.location.href='<?php echo base_url('user_management/user_category/delete/')?>/'+user_category;     
        }
    }
</script>