<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="page-header">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-lg-6 col-xl-6">
                    <h3 class="page-title">User Management</h3>
                    <ul class="breadcrumb">
                    <li class="breadcrumb-item">Operations List</li>
                    <li class="breadcrumb-item active">Add Operations</li>
                    </ul>
                    </div>
                </div>
            </div>
            <div class="row" style="margin-right: 0px;">
                <div class="col-md-12 col-sm-12 col-lg-6 col-xl-10">
                    <div class="card">
                        <div class="card-body">

                            <form action="<?php echo base_url('user_management/operations_list/add');?>" method="post">
                                <div class="form-group col-md-12 col-sm-12 col-lg-6 col-xl-5">
                                    <label>User Category</label>
                                    <select name="user_category" class="form-control mt-2" required>
                                        <option value="">Select User</option>
                                        <?php 
                                        foreach($user_categorys as $user_category)
                                        echo "<option value='".$user_category['id']."'>".$user_category['title']."</option>";
                                        ?>                      
                                    </select> 
                                </div>

                                <table><thead class="p-3 m-3 text-center"><tr><th>Operation</th><th>Read</th><th>Write</th><th>Update</th><th>delete</th></tr></thead>
                                  <tbody class="text-center">
                                    <tr><td> <input class="form-control p-3"  name="operation" value="Employee"></td>
                                    <td>
                                        <!-- ================ Toggle Switch Button =============== -->
                                        <!-- <div class="input-group p-3">

                                            <div class="toggle-switch-btn">
                                                <div class="toggle">
                                                    <div class="toggle-button" onclick="Animatedtoggle()">
                                                        
                                                    </div>
                                                    <div class="text">
                                                        ON&nbsp;&nbsp;OFF
                                                    </div>
                                                </div>
                                            </div>
                                            <script>
                                                let toggle= document.querySelector(".toggle");
                                                function Animatedtoggle(){
                                                    toggle.classList.toggle("active");

                                                }
                                            </script>
                                        </div> -->
                                        
                                        <div class="input-group p-3">                                        
                                            <div class="input-group-text">
                                                <input class="form-check-input mt-0" type="radio" name="read"  value="on">
                                            </div>                                    
                                            <label class="form-control px-2 pt-2">On</label>
                                        </div>
                                        <div class="input-group p-3">
                                         <div class="input-group-text">
                                            <input class="form-check-input mt-0" type="radio" name="read"  value="off" checked>
                                            </div>                                    
                                            <label class="form-control px-3 pt-2">Off</label>
                                        </div>
                                    </td>
                                    <td>  <div class="input-group p-3">
                                        
                                        <div class="input-group-text">
                                            <input class="form-check-input mt-0" type="radio" name="write"  value="on">
                                        </div>                                    
                                        <label class="form-control px-3 pt-2">
                                        On
                                        </label>
                                        </div>
                                        <div class="input-group p-3">
                                        <div class="input-group-text">
                                            <input class="form-check-input mt-0" type="radio" name="write"  value="off" checked>
                                        </div>                                    
                                        <label class="form-control px-3 pt-2">
                                        Off
                                        </label>
                                        </div></td>
                                    <td>  <div class="input-group p-3">
                                        
                                        <div class="input-group-text">
                                            <input class="form-check-input mt-0" type="radio" name="update"  value="on">
                                        </div>                                    
                                        <label class="form-control px-3 pt-2">
                                        On
                                        </label>
                                        </div>
                                        <div class="input-group p-3">
                                        <div class="input-group-text">
                                            <input class="form-check-input mt-0" type="radio" name="update"  value="off" checked>
                                        </div>                                    
                                        <label class="form-control px-3 pt-2">
                                    Off
                                        </label>
                                        </div></td>
                                    <td>  <div class="input-group p-3">
                                        
                                        <div class="input-group-text">
                                            <input class="form-check-input mt-0" type="radio" name="delete"  value="on">
                                        </div>                                    
                                        <label class="form-control px-3 pt-2">
                                        On
                                        </label>
                                        </div>
                                        <div class="input-group p-3">
                                        <div class="input-group-text">
                                            <input class="form-check-input mt-0" type="radio" name="delete"  value="off" checked>
                                        </div>                                    
                                        <label class="form-control px-3 pt-2">
                                    Off
                                        </label>
                                        </div></td>
                                    </tr>
                                  </tbody>
                            
                                </table>
                                <br>
                                <div class="form-group text-end">
                                    <button class="btn btn-primary account-btn" type="submit">Submit</button>
                                </div>
                            
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>               

<?=$this->endSection()?>