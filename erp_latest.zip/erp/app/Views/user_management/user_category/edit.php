<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">

<div class="content container-fluid">

<div class="page-header">
<div class="row">
<div class="col-sm-12">
<h3 class="page-title">User Management</h3>
<ul class="breadcrumb">
<li class="breadcrumb-item active">Update</li>
</ul>
</div>
</div>
</div>

<div class="row">
<div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
<div class="card">
<div class="card-body">

                        <form name="updateForm" id="updateForm" method="post" action="<?php echo base_url('user_management/user_category/edit/'.$user_category['id']);?>">
                            <div class="form-group">
                                <label>TITLE NAME</label>
                                <input type="text" placeholder="Enter Title Name" name="title" id="title" class="form-control <?php echo (isset($validation) && $validation->hasError('title')) ? 'is-invalid' : '';?>" value="<?php echo set_value('title',$user_category['title']);?>">
                                <?php
                                    if(isset($validation) && $validation->hasError('title'))
                                    {
                                        echo '<p class="invalid-feedback">'.$validation->getError('title').'</p>';
                                    }
                                ?>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">update</button>
                        </form>
                    </div>
                </div>
</div>
</div>
</div>
</div>
</div>
</div>

<?=$this->endSection()?>