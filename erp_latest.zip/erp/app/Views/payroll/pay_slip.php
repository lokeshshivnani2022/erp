<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">

    <div class="content container-fluid">

        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Payslip</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin-dashboard.html">Dashboard</a></li>
                        <li class="breadcrumb-item active">Payslip</li>
                    </ul>
                </div>
                <div class="col-auto float-end ms-auto">
                    <div class="btn-group btn-group-sm">
                        <button class="btn btn-white">CSV</button>
                        <button class="btn btn-white">PDF</button>
                        <button class="btn btn-white"><i class="fa fa-print fa-lg"></i> Print</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="payslip-title">M.P. STATE SEED CERTIFICATION AGENCY, BHOPAL</h4>
                        <h4 class="payslip text-center"><u>Pay Bill of the Establishment for the Month of JULY-2022</u></h4>
                        <div class="row">
                            <div class="col-sm-6 m-b-20">
                                <img src="<?=base_url('public/assets/img/logo2.png')?>" class="inv-logo" alt="">
                                <ul class="list-unstyled mb-0">
                                    <li>Company Name</li>
                                    <li>Address line 1</li>
                                    <li>Address line 2</li>
                                </ul>
                            </div>
                            <div class="col-sm-6 m-b-20">
                                <div class="invoice-details">
                                    <h3 class="text-uppercase">Payslip #49029</h3>
                                    <ul class="list-unstyled">
                                        <li>Salary Month: <span>JULY, 2022</span></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 m-b-20">
                                <ul class="list-unstyled">
                                    <li>
                                        <h5 class="mb-0"><strong>Employee Name</strong></h5>
                                    </li>
                                    <li><span>Employee Designation</span></li>
                                    <li>Employee ID</li>
                                    <li>Joining Date</li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 m-b-40">
                                <div class="table-wrapper">
                                    <table class="table-bordered">
                                        <tbody>                                            
                                            <tr>
                                                <th rowspan="3"><br>S.no.</th>
                                                <th rowspan="3"><br>Name <br> & <br> Designation</th>
                                                <th rowspan="1">7th Pay</th>
                                                <th rowspan="3"><br>Allow.</th>
                                                <th rowspan="3"><br>Amount</th>
                                                <th rowspan="3">Total<br>(in Rs.)<br>(3+5)</th>
                                                <th rowspan="1" colspan="6">Deductions</th>
                                                <th rowspan="3">Total<br>Decu.<br>(9+10+12)</th>
                                                <th rowspan="3">Net<br>Payable<br>(6-13)</th>
                                                <th rowspan="3"><br>C.P.F<br>A/c No.</th>
                                                <th rowspan="3"><br>S.B<br>A/c No.</th>
                                                <th rowspan="3"><br>Remark</th>                                                    
                                            </tr>
                                            <tr>
                                                <th rowspan="2"><br>Basic</th>
                                                <th rowspan="1" colspan="3">Agency's deductions</th>
                                                <th rowspan="1" colspan="3">Other deductions</th>
                                            </tr>
                                            <tr>
                                                <th>Parti</th>
                                                <th>Int. No.</th>
                                                <th>Amount</th>
                                                <th>C.P.F</th>
                                                <th>Parti.</th>
                                                <th>Amount</th>
                                            </tr>
                                            <tr>
                                                <th>1</th>
                                                <th>2</th>
                                                <th>3</th>
                                                <th>4</th>
                                                <th>5</th>
                                                <th>6</th>
                                                <th>7</th>
                                                <th>8</th>
                                                <th>9</th>
                                                <th>10</th>
                                                <th>11</th>
                                                <th>12</th>
                                                <th>13</th>
                                                <th>14</th>
                                                <th>15</th>
                                                <th>16</th>
                                                <th>17</th>
                                            </tr>
                                            <tr>
                                                <td rowspan="9"class="text-center"><br><br>16</td>
                                                <td rowspan="9"><br>Shri brajraj Singh<br>asstt.Gr-III<br>28700-91300(7)<br>DA@31%<br>PIC NO. 1189/EST/577/PF/2022 DT.25.07.2022</td>
                                                <td>46100.00</td>
                                                <td>D.A</td>
                                                <td>14291.00</td>
                                                <td>62107.00</td>
                                                <td>M.C.A/Ag.</td>
                                                <td>---</td>
                                                <td>0.00</td>
                                                <td>7247.00</td>
                                                <td>G.I.S</td>
                                                <td>0.00</td>
                                                <td>7896.00</td>
                                                <td>54211.00</td>
                                                <td rowspan="9">MP-<br>5644/141</td>
                                                <td rowspan="9">60358729868</td>
                                                <td> </td>
                                            </tr>
                                            <tr>
                                                <td>---</td>
                                                <td>C.C.A</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>M.C.A/N</td>
                                                <td>---</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>Pf. Tax</td>
                                                <td>500.00</td>
                                                <td>---</td>
                                                <td>---</td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td>---</td>
                                                <td>H.R.A</td>
                                                <td>1516.00</td>
                                                <td>---</td>
                                                <td>F.Ad</td>
                                                <td>---</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>In. Tax</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>---</td>
                                                <td></td>
                                            </tr><tr>
                                                <td>---</td>
                                                <td>C.A</td>
                                                <td>200.00</td>
                                                <td>---</td>
                                                <td>G.Ad</td>
                                                <td>---</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>H.Rent</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>---</td>
                                                <td></td>
                                            </tr><tr>
                                                <td>---</td>
                                                <td>O.A</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>Pay/C.A</td>
                                                <td>---</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>L.I.C</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>---</td>
                                                <td></td>
                                            </tr><tr>
                                                <td>---</td>
                                                <td>W.All.</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>Pay/Ad.</td>
                                                <td>---</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>L.I.C</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>---</td>
                                                <td></td>
                                            </tr><tr>
                                                <td>---</td>
                                                <td>M.All.</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>Int. On Ad.</td>
                                                <td>---</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>L.I.C</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>---</td>
                                                <td></td>
                                            </tr><tr>
                                                <td>---</td>
                                                <td>MAc. All.</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>P.O.L</td>
                                                <td>---</td>
                                                <td>250.00</td>
                                                <td>---</td>
                                                <td>L.I.C</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>---</td>
                                                <td></td>
                                            </tr><tr>
                                                <td>---</td>
                                                <td>OTHER</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>other</td>
                                                <td>---</td>
                                                <td>0.00</td>
                                                <td>---</td>
                                                <td>G.S.L.I.S</td>
                                                <td>239.00</td>
                                                <td>---</td>
                                                <td>---</td>
                                                <td></td>
                                                </tr>    
                                                <tr>
                                                <td></td>
                                                <td><b>TOTAL</b></td>
                                                <td><b>46100.00</b></td>
                                                <td></td>
                                                <td><b>16007.00</b></td>
                                                <td><b>62107.00</b></td>
                                                <td></td>
                                                <td></td>
                                                <td><b>0.00</b></td>
                                                <td><b>7247.00</b></td>
                                                <td></td>
                                                <td><b>649.00</b></td>
                                                <td><b>7896.00</b></td>
                                                <td><b>54211.00</b></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?=$this->endSection()?>