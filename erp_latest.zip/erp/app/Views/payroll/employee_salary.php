<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>

<div class="page-wrapper">

            <div class="content container-fluid">

                <div class="page-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="page-title">Employee Salary</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="admin-dashboard.html">Dashboard</a></li>
                                <li class="breadcrumb-item active">Salary</li>
                            </ul>
                        </div>
                        <div class="col-auto float-end ms-auto">
                            <a href="#" class="btn add-btn" data-bs-toggle="modal" data-bs-target="#add_salary"><i
                                    class="fa fa-plus"></i> Add Salary</a>
                        </div>
                    </div>
                </div>


                <div class="row filter-row">
                    <div class="col-sm-6 col-md-3 col-lg-3 col-xl-2 col-12">
                        <div class="form-group form-focus">
                            <input type="text" class="form-control floating">
                            <label class="focus-label">Employee Name</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 col-xl-2 col-12">
                        <div class="form-group form-focus select-focus">
                            <select class="select floating">
                                <option value=""> -- Select -- </option>
                                <option value="">Employee</option>
                                <option value="1">Manager</option>
                            </select>
                            <label class="focus-label">Role</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 col-xl-2 col-12">
                        <div class="form-group form-focus select-focus">
                            <select class="select floating">
                                <option> -- Select -- </option>
                                <option> Pending </option>
                                <option> Approved </option>
                                <option> Rejected </option>
                            </select>
                            <label class="focus-label">Leave Status</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 col-xl-2 col-12">
                        <div class="form-group form-focus">
                            <div class="cal-icon">
                                <input class="form-control floating datetimepicker" type="text">
                            </div>
                            <label class="focus-label">From</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 col-xl-2 col-12">
                        <div class="form-group form-focus">
                            <div class="cal-icon">
                                <input class="form-control floating datetimepicker" type="text">
                            </div>
                            <label class="focus-label">To</label>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-lg-3 col-xl-2 col-12">
                        <a href="#" class="btn btn-success w-100"> Search </a>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="table-responsive">
                            <table class="table table-striped custom-table datatable">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>Employee ID</th>
                                        <th>Email</th>
                                        <th>Join Date</th>
                                        <th>Role</th>
                                        <th>Salary</th>
                                        <th>Payslip</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img alt=""
                                                        src="assets/img/profiles/avatar-02.jpg"></a>
                                                <a href="profile.html">John Doe <span>Web Designer</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0001</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="22484d4a4c464d4762475a434f524e470c414d4f">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Web Designer </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$59698</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-09.jpg" alt=""></a>
                                                <a href="profile.html">Richard Miles <span>Web Developer</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0002</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="186a717b70796a7c7571747d6b587d60797568747d367b7775">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Web Developer </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$72000</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-10.jpg" alt=""></a>
                                                <a href="profile.html">John Smith <span>Android Developer</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0003</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="4c262324223f212538240c29342d213c2029622f2321">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Android Developer
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$48200</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-05.jpg" alt=""></a>
                                                <a href="profile.html">Mike Litorus <span>IOS Developer</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0004</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="85e8eceee0e9ecf1eaf7f0f6c5e0fde4e8f5e9e0abe6eae8">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">IOS Developer </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$59698</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-11.jpg" alt=""></a>
                                                <a href="profile.html">Wilmer Deluna <span>Team Leader</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0005</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="bccbd5d0d1d9ced8d9d0c9d2ddfcd9c4ddd1ccd0d992dfd3d1">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Team Leader </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$43000</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-12.jpg" alt=""></a>
                                                <a href="profile.html">Jeffrey Warden <span>Web Developer</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0006</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="f69c93909084938f819784929398b6938e979b869a93d895999b">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Web Developer</a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$45000</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-13.jpg" alt=""></a>
                                                <a href="profile.html">Bernardo Galaviz <span>Web Developer</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0007</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="86e4e3f4e8e7f4e2e9e1e7eae7f0effcc6e3fee7ebf6eae3a8e5e9eb">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2014</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Web Developer </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$38400</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-01.jpg" alt=""></a>
                                                <a href="profile.html">Lesley Grauer <span>Team Leader</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0008</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="365a53455a534f51445743534476534e575b465a531855595b">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jun 2015</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Team Leader </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$75500</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-16.jpg" alt=""></a>
                                                <a href="profile.html">Jeffery Lalor <span>Team Leader</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0009</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="28424d4e4e4d5a51444944475a684d50494558444d064b4745">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Team Leader </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$73550</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-04.jpg" alt=""></a>
                                                <a href="profile.html">Loren Gatlin <span>Android Developer</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0010</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="0c60637e69626b6d786065624c69746d617c6069226f6361">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Android Developer
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$55000</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <h2 class="table-avatar">
                                                <a href="profile.html" class="avatar"><img
                                                        src="assets/img/profiles/avatar-03.jpg" alt=""></a>
                                                <a href="profile.html">Tarah Shropshire <span>Android
                                                        Developer</span></a>
                                            </h2>
                                        </td>
                                        <td>FT-0011</td>
                                        <td><a href="/cdn-cgi/l/email-protection" class="__cf_email__"
                                                data-cfemail="93e7f2e1f2fbe0fbe1fce3e0fbfae1f6d3f6ebf2fee3fff6bdf0fcfe">[email&#160;protected]</a>
                                        </td>
                                        <td>1 Jan 2013</td>
                                        <td>
                                            <div class="dropdown">
                                                <a href="" class="btn btn-white btn-sm btn-rounded dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false">Android Developer
                                                </a>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="#">Software Engineer</a>
                                                    <a class="dropdown-item" href="#">Software Tester</a>
                                                    <a class="dropdown-item" href="#">Frontend Developer</a>
                                                    <a class="dropdown-item" href="#">UI/UX Developer</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>$92400</td>
                                        <td><a class="btn btn-sm btn-primary" href="salary-view.html">Generate Slip</a>
                                        </td>
                                        <td class="text-end">
                                            <div class="dropdown dropdown-action">
                                                <a href="#" class="action-icon dropdown-toggle"
                                                    data-bs-toggle="dropdown" aria-expanded="false"><i
                                                        class="material-icons">more_vert</i></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#edit_salary"><i class="fa fa-pencil m-r-5"></i>
                                                        Edit</a>
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal"
                                                        data-bs-target="#delete_salary"><i
                                                            class="fa fa-trash-o m-r-5"></i> Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


            <div id="add_salary" class="modal custom-modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Staff Salary</h5>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Select Staff</label>
                                            <select class="select">
                                                <option>John Doe</option>
                                                <option>Richard Miles</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label>Net Salary</label>
                                        <input class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <h4 class="text-primary">Earnings</h4>
                                        <div class="form-group">
                                            <label>Basic</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>DA(40%)</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>HRA(15%)</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Conveyance</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Allowance</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Medical Allowance</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Others</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="add-more">
                                            <a href="#"><i class="fa fa-plus-circle"></i> Add More</a>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <h4 class="text-primary">Deductions</h4>
                                        <div class="form-group">
                                            <label>TDS</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>ESI</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>PF</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Leave</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Prof. Tax</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Labour Welfare</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="form-group">
                                            <label>Others</label>
                                            <input class="form-control" type="text">
                                        </div>
                                        <div class="add-more">
                                            <a href="#"><i class="fa fa-plus-circle"></i> Add More</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="submit-section">
                                    <button class="btn btn-primary submit-btn">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <div id="edit_salary" class="modal custom-modal fade" role="dialog">
                <div class="modal-dialog modal-dialog-centered modal-md" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Staff Salary</h5>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Select Staff</label>
                                            <select class="select">
                                                <option>John Doe</option>
                                                <option>Richard Miles</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <label>Net Salary</label>
                                        <input class="form-control" type="text" value="$4000">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <h4 class="text-primary">Earnings</h4>
                                        <div class="form-group">
                                            <label>Basic</label>
                                            <input class="form-control" type="text" value="$6500">
                                        </div>
                                        <div class="form-group">
                                            <label>DA(40%)</label>
                                            <input class="form-control" type="text" value="$2000">
                                        </div>
                                        <div class="form-group">
                                            <label>HRA(15%)</label>
                                            <input class="form-control" type="text" value="$700">
                                        </div>
                                        <div class="form-group">
                                            <label>Conveyance</label>
                                            <input class="form-control" type="text" value="$70">
                                        </div>
                                        <div class="form-group">
                                            <label>Allowance</label>
                                            <input class="form-control" type="text" value="$30">
                                        </div>
                                        <div class="form-group">
                                            <label>Medical Allowance</label>
                                            <input class="form-control" type="text" value="$20">
                                        </div>
                                        <div class="form-group">
                                            <label>Others</label>
                                            <input class="form-control" type="text">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <h4 class="text-primary">Deductions</h4>
                                        <div class="form-group">
                                            <label>TDS</label>
                                            <input class="form-control" type="text" value="$300">
                                        </div>
                                        <div class="form-group">
                                            <label>ESI</label>
                                            <input class="form-control" type="text" value="$20">
                                        </div>
                                        <div class="form-group">
                                            <label>PF</label>
                                            <input class="form-control" type="text" value="$20">
                                        </div>
                                        <div class="form-group">
                                            <label>Leave</label>
                                            <input class="form-control" type="text" value="$250">
                                        </div>
                                        <div class="form-group">
                                            <label>Prof. Tax</label>
                                            <input class="form-control" type="text" value="$110">
                                        </div>
                                        <div class="form-group">
                                            <label>Labour Welfare</label>
                                            <input class="form-control" type="text" value="$10">
                                        </div>
                                        <div class="form-group">
                                            <label>Fund</label>
                                            <input class="form-control" type="text" value="$40">
                                        </div>
                                        <div class="form-group">
                                            <label>Others</label>
                                            <input class="form-control" type="text" value="$15">
                                        </div>
                                    </div>
                                </div>
                                <div class="submit-section">
                                    <button class="btn btn-primary submit-btn">Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <div class="modal custom-modal fade" id="delete_salary" role="dialog">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="form-header">
                                <h3>Delete Salary</h3>
                                <p>Are you sure want to delete?</p>
                            </div>
                            <div class="modal-btn delete-action">
                                <div class="row">
                                    <div class="col-6">
                                        <a href="javascript:void(0);" class="btn btn-primary continue-btn">Delete</a>
                                    </div>
                                    <div class="col-6">
                                        <a href="javascript:void(0);" data-bs-dismiss="modal"
                                            class="btn btn-primary cancel-btn">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

<?=$this->endSection()?>