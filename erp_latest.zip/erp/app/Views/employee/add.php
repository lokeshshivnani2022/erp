<?=$this->extend('layouts/baselayout')?>
<?=$this->section('body')?>
<div class="page-wrapper">

    <div class="content container-fluid">

        <div class="page-header">
            <?php //echo form_open('/employee/view');?>
            <div class="row">
                <div class="col-sm-12">
                <h3 class="page-title">Employee Registration</h3>
                <ul class="breadcrumb">
                <li class="breadcrumb-item active">Add New Employee</li>
                </ul>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-lg-12 col-xl-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?=base_url('employee/add')?>" method="post">                            
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label class="form-label">First Name</label>
                                    <input class="form-control <?php echo (isset($validation) && $validation->hasError('first_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('first_name');?>" type="text" name="first_name">
                                    <?php
                                        if(isset($validation) && $validation->hasError('first_name'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('first_name').'</p>';
                                        }
                                    ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Middle Name</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('middle_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('middle_name');?> " name="middle_name">
                                    <?php
                                        if(isset($validation) && $validation->hasError('middle_name'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('middle_name').'</p>';
                                        }
                                    ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Last Name</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('last_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('last_name');?> " name="last_name">
                                    <?php
                                        if(isset($validation) && $validation->hasError('last_name'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('last_name').'</p>';
                                        }
                                    ?>                                    
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">DOB</label>
                                    <input type="date" class="form-control <?php echo (isset($validation) && $validation->hasError('dob')) ? 'is-invalid' : '';?>" value="<?php echo set_value('dob');?> " name="dob">
                                    <?php
                                        if(isset($validation) && $validation->hasError('dob'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('dob').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Gender</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('gender')) ? 'is-invalid' : '';?>" value="<?php echo set_value('gender');?> " name="gender">
                                    <?php
                                        if(isset($validation) && $validation->hasError('gender'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('gender').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Father Name</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('father_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('father_name');?> " name="father_name">
                                    <?php
                                        if(isset($validation) && $validation->hasError('father_name'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('father_name').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Mother Name</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('mother_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('mother_name');?> " name="mother_name">
                                    <?php
                                        if(isset($validation) && $validation->hasError('mother_name'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('mother_name').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" class="form-control <?php echo (isset($validation) && $validation->hasError('email')) ? 'is-invalid' : '';?>" value="<?php echo set_value('email');?> " name="email">
                                    <?php
                                        if(isset($validation) && $validation->hasError('email'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('email').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">City</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('city')) ? 'is-invalid' : '';?>" value="<?php echo set_value('city');?> " name="city">
                                    <?php
                                        if(isset($validation) && $validation->hasError('city'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('city').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">State</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('state')) ? 'is-invalid' : '';?>" value="<?php echo set_value('state');?> " name="state">
                                    <?php
                                        if(isset($validation) && $validation->hasError('state'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('state').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Country</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('country')) ? 'is-invalid' : '';?>" value="<?php echo set_value('country');?> " name="country">
                                    <?php
                                        if(isset($validation) && $validation->hasError('country'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('country').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Department</label>
                                        <select name="dep_id" class="form-control">
                                            <?php 
                                            foreach($departments as $department)
                                            echo "<option value='".$department['dep_id']."'>".$department['dep_name']."</option>";
                                            ?>                      
                                        </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Designation</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('designation')) ? 'is-invalid' : '';?>" value="<?php echo set_value('designation');?> " name="designation">
                                    <?php
                                        if(isset($validation) && $validation->hasError('designation'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('designation').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Zip Code</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('zip_code')) ? 'is-invalid' : '';?>" value="<?php echo set_value('zip_code');?> " name="zip_code">
                                    <?php
                                        if(isset($validation) && $validation->hasError('zip_code'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('zip_code').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Current Address</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('current_address')) ? 'is-invalid' : '';?>" value="<?php echo set_value('current_address');?> " name="current_address">
                                    <?php
                                        if(isset($validation) && $validation->hasError('current_address'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('current_address').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Permanent Address</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('permanent_address')) ? 'is-invalid' : '';?>" value="<?php echo set_value('permanent_address');?> " name="permanent_address">
                                    <?php
                                        if(isset($validation) && $validation->hasError('permanent_address'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('permanent_address').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Mobile Number</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('mobile_number')) ? 'is-invalid' : '';?>" value="<?php echo set_value('mobile_number');?> " name="mobile_number">
                                    <?php
                                        if(isset($validation) && $validation->hasError('mobile_number'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('mobile_number').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Alternate Mobile Number</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('alternate_mobile_number')) ? 'is-invalid' : '';?>" value="<?php echo set_value('alternate_mobile_number');?> " name="alternate_mobile_number">
                                    <?php
                                        if(isset($validation) && $validation->hasError('alternate_mobile_number'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('alternate_mobile_number').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Bio</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('bio')) ? 'is-invalid' : '';?>" value="<?php echo set_value('bio');?> " name="bio">
                                    <?php
                                        if(isset($validation) && $validation->hasError('bio'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('bio').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Job Title</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('job_title')) ? 'is-invalid' : '';?>" value="<?php echo set_value('job_title');?> " name="job_title">
                                    <?php
                                        if(isset($validation) && $validation->hasError('job_title'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('job_title').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Company Name</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('company_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('company_name');?> " name="company_name">
                                    <?php
                                        if(isset($validation) && $validation->hasError('company_name'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('company_name').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Job Start Date</label>
                                    <input type="date" class="form-control <?php echo (isset($validation) && $validation->hasError('job_start_date')) ? 'is-invalid' : '';?>" value="<?php echo set_value('job_start_date');?> " name="job_start_date">
                                    <?php
                                        if(isset($validation) && $validation->hasError('job_start_date'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('job_start_date').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Job End Date</label>
                                    <input type="date" class="form-control <?php echo (isset($validation) && $validation->hasError('job_end_date')) ? 'is-invalid' : '';?>" value="<?php echo set_value('job_end_date');?> " name="job_end_date">
                                    <?php
                                        if(isset($validation) && $validation->hasError('job_end_date'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('job_end_date').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Job Role/Experience</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('job_role_experience')) ? 'is-invalid' : '';?>" value="<?php echo set_value('job_role_experience');?> " name="job_role_experience">
                                    <?php
                                        if(isset($validation) && $validation->hasError('job_role_experience'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('job_role_experience').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Marks Obtained in 10th</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('marks_obtained_in_10th')) ? 'is-invalid' : '';?>" value="<?php echo set_value('marks_obtained_in_10th');?> " name="marks_obtained_in_10th">
                                    <?php
                                        if(isset($validation) && $validation->hasError('marks_obtained_in_10th'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('marks_obtained_in_10th').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Upload 10th Marksheet</label>
                                    <input type="file" class="form-control <?php echo (isset($validation) && $validation->hasError('upload_10th_marksheet')) ? 'is-invalid' : '';?>" value="<?php echo set_value('upload_10th_marksheet');?> " name="upload_10th_marksheet">
                                    <?php
                                        if(isset($validation) && $validation->hasError('upload_10th_marksheet'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('upload_10th_marksheet').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Marks Obtained in 12th</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('marks_obtained_in_12th')) ? 'is-invalid' : '';?>" value="<?php echo set_value('marks_obtained_in_12th');?> " name="marks_obtained_in_12th">
                                    <?php
                                        if(isset($validation) && $validation->hasError('marks_obtained_in_12th'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('marks_obtained_in_12th').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Upload 12th Marksheet</label>
                                    <input type="file" class="form-control <?php echo (isset($validation) && $validation->hasError('upload_12th_marksheet')) ? 'is-invalid' : '';?>" value="<?php echo set_value('upload_12th_marksheet');?> " name="upload_12th_marksheet">
                                    <?php
                                        if(isset($validation) && $validation->hasError('upload_12th_marksheet'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('upload_12th_marksheet').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Highest Qualification</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('highest_qualification')) ? 'is-invalid' : '';?>" value="<?php echo set_value('highest_qualification');?> " name="highest_qualification">
                                    <?php
                                        if(isset($validation) && $validation->hasError('highest_qualification'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('highest_qualification').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Highest Marks</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('highest_marks')) ? 'is-invalid' : '';?>" value="<?php echo set_value('highest_marks');?> " name="highest_marks">
                                    <?php
                                        if(isset($validation) && $validation->hasError('highest_marks'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('highest_marks').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Upload Marksheet</label>
                                    <input type="file" class="form-control <?php echo (isset($validation) && $validation->hasError('upload_marksheet')) ? 'is-invalid' : '';?>" value="<?php echo set_value('upload_marksheet');?> " name="upload_marksheet">
                                    <?php
                                        if(isset($validation) && $validation->hasError('upload_marksheet'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('upload_marksheet').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Bank Name</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('bank_name')) ? 'is-invalid' : '';?>" value="<?php echo set_value('bank_name');?> " name="bank_name">
                                    <?php
                                        if(isset($validation) && $validation->hasError('bank_name'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('bank_name').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Account Number</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('account_number')) ? 'is-invalid' : '';?>" value="<?php echo set_value('account_number');?> " name="account_number">
                                    <?php
                                        if(isset($validation) && $validation->hasError('account_number'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('account_number').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">IFSC Code</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('ifsc_code')) ? 'is-invalid' : '';?>" value="<?php echo set_value('ifsc_code');?> " name="ifsc_code">
                                    <?php
                                        if(isset($validation) && $validation->hasError('ifsc_code'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('ifsc_code').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Upload Bank Passbook</label>
                                    <input type="file" class="form-control <?php echo (isset($validation) && $validation->hasError('upload_bank_passbook')) ? 'is-invalid' : '';?>" value="<?php echo set_value('upload_bank_passbook');?> " name="upload_bank_passbook">
                                    <?php
                                        if(isset($validation) && $validation->hasError('upload_bank_passbook'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('upload_bank_passbook').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Aadhar Number</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('aadhar_number')) ? 'is-invalid' : '';?>" value="<?php echo set_value('aadhar_number');?> " name="aadhar_number">
                                    <?php
                                        if(isset($validation) && $validation->hasError('aadhar_number'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('aadhar_number').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Upload Front Side of Aadhar Card</label>
                                    <input type="file" class="form-control <?php echo (isset($validation) && $validation->hasError('upload_front_side_of_aadhar_card')) ? 'is-invalid' : '';?>" value="<?php echo set_value('upload_front_side_of_aadhar_card');?> " name="upload_front_side_of_aadhar_card">
                                    <?php
                                        if(isset($validation) && $validation->hasError('upload_front_side_of_aadhar_card'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('upload_front_side_of_aadhar_card').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Upload Back Side of Aadhar Card</label>
                                    <input type="file" class="form-control <?php echo (isset($validation) && $validation->hasError('upload_back_side_of_aadhar_card')) ? 'is-invalid' : '';?>" value="<?php echo set_value('upload_back_side_of_aadhar_card');?> " name="upload_back_side_of_aadhar_card">
                                    <?php
                                        if(isset($validation) && $validation->hasError('upload_back_side_of_aadhar_card'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('upload_back_side_of_aadhar_card').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">PAN Number</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('pan_number')) ? 'is-invalid' : '';?>" value="<?php echo set_value('pan_number');?> " name="pan_number">
                                    <?php
                                        if(isset($validation) && $validation->hasError('pan_number'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('pan_number').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Upload PAN Card Image</label>
                                    <input type="file" class="form-control <?php echo (isset($validation) && $validation->hasError('upload_pan_card_image')) ? 'is-invalid' : '';?>" value="<?php echo set_value('upload_pan_card_image');?> " name="upload_pan_card_image">
                                    <?php
                                        if(isset($validation) && $validation->hasError('upload_pan_card_image'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('upload_pan_card_image').'</p>';
                                        }
                                    ?>  
                                </div>
                                <div class="form-group col-md-6">
                                    <label class="form-label">Password</label>
                                    <input type="text" class="form-control <?php echo (isset($validation) && $validation->hasError('password')) ? 'is-invalid' : '';?>" value="<?php echo set_value('password');?> " name="password">
                                    <?php
                                        if(isset($validation) && $validation->hasError('password'))
                                        {
                                            echo '<p class="invalid-feedback">'.$validation->getError('password').'</p>';
                                        }
                                    ?>  
                                </div> 
                                <div class="form-group text-end">
                                    <button class="btn btn-primary account-btn" type="submit">Submit</button>
                                </div>                               
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?=$this->endSection()?>