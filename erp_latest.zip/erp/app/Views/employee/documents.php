

<div class="row">

    <div class="col-md-6 mb-3">
        <label for="" class="form-label">Aadhaar Number</label>
        <input type="text" class="form-control"
            placeholder="Enter Aadhaar Number" wire:model="aadhaar_no">

        <img src="">
    </div>
    <div class="col-md-3 mb-3">
        <label for="" class="form-label">Upload Front Side Aadhaar
            Card</label>
        <input type="file" class="form-control"
            wire:model="aadhaar_image_front">
    </div>
    <div class="col-md-3 mb-3">
        <label for="" class="form-label">Upload Back Side Aadhaar
            Card</label>
        <input type="file" class="form-control"
            wire:model="aadhaar_image_back">
    </div>

    <div class="col-md-6 mb-3">
        <label for="" class="form-label">Pan Card Number</label>
        <input type="text" class="form-control"
            placeholder="Enter Pan Card Number"
            wire:model="pan_card_no">


    </div>

    <div class="col-md-6 mb-3">
        <label for="" class="form-label">Upload Pan Card Image</label>
        <input type="file" class="form-control"
            wire:model="pan_card_image">
    </div>
</div> <!-- end row -->                                                
                                                    

<a href="<?php echo base_url('profile/banking/');?>" class="btn btn-primary mobile-btn float-end">Submit</a>                                         
              