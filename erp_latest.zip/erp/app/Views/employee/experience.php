
                    <div class="form-group row">
                        <label >Job Title</label>
                       
                            <input type="text" class="form-control" placeholder="Enter title for job role">
                       
                    </div>
                    <div class="form-group row">
                        <label>Company Name</label>
                        
                            <input type="text" class="form-control" placeholder="Enter Company Name">
                       
                    </div>                        
                        <div class="form-group row">
                            <label class="form-label">Job Start Date</label>
                            <div class="col-lg-9">
                                <input type="date" class="form-control" >
                            </div>
                    </div>
                    <div class="form-group row">
                        <label class="form-label">Job End Date</label>
                        <div class="col-lg-9">
                            <input type="date" class="form-control">
                        </div>
                    </div>                                    
                    <div class="form-group row">
                        <label for="userbio"
                            class="form-label">Job Role/Experience Description</label>
                        <div class="col-lg-9">
                            <textarea class="form-control" wire:model="aboutme" id="userbio"
                                rows="4" placeholder="Write your Experience Here"></textarea>
                        </div>
                    </div>                                    
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <li class="page-item ">
                            <a class="page-link" href="<?php echo base_url('profile/personal_information/');?>" tabindex="-1">Previous</a>
                            </li>
                            <li class="page-item "><a class="page-link" href="<?php echo base_url('profile/personal_information/');?>">1</a></li>
                            <li class="page-item disabled"><a class="page-link" href="<?php echo base_url('profile/experience/');?>">2</a></li>
                            <li class="page-item"><a class="page-link" href="<?php echo base_url('profile/academics/');?>">3</a></li>
                            <li class="page-item"><a class="page-link" href="<?php echo base_url('profile/banking/');?>">4</a></li>
                            <li class="page-item"><a class="page-link" href="<?php echo base_url('profile/documents/');?>">5</a></li>
                            <li class="page-item">
                            <a class="page-link" href="<?php echo base_url('profile/academics/');?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </form>
        </div>
    </div>
</div>