    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Full Name</label>
        <div class="col-lg-9 ">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Gender</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">DOB</label>
        <div class="col-lg-9">
            <input type="email" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Father's Name</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Mother's Name</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Current
            Address</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Permanent
            Address</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Mobile Number</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Alternate Mobile
            Number</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">City</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">State</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-lg-3 col-form-label basic-form-lbl">Country</label>
        <div class="col-lg-9">
            <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="userbio"
            class="col-lg-3 col-form-label basic-form-lbl">Bio</label>
        <div class="col-lg-9">
            <textarea class="form-control" wire:model="aboutme" id="userbio"
                rows="4" placeholder="Write something..."></textarea>
        </div>
    </div>
    <div class="form-group row">
        <label for="useremail" class="col-lg-3 col-form-label basic-form-lbl">Email
            Address</label>
        <div class="col-lg-9">
            <input class="form-control" type="email" wire:model="email"
                placeholder="Enter email">
        </div>
    </div>
</div>



