<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index',['filter' => 'noauth']);
$routes->match(['get','post'],'/signup','AuthController::register',['filter' => 'noauth']);
$routes->match(['get','post'],'/login','AuthController::login',['filter' => 'noauth']);
$routes->get('/logout', 'AuthController::logout', ['filter' => 'auth']);
$routes->get('/dashboard', 'AdminController::dashboard',['filter' => 'auth']);

$routes->get('/accounting/budget_revenues','AdminController::budget_revenues');
$routes->get('/accounting/budget_expenses','AdminController::budget_expenses');
$routes->get('/accounting/budgets','AdminController::budgets');
$routes->get('/accounting/categories','AdminController::categories');

$routes->get('/payroll/employee_salary','AdminController::employee_salary');
$routes->get('/payroll/pay_slip','AdminController::pay_slip');
$routes->get('/payroll/payroll_items','AdminController::payroll_items');

$routes->get('/multi_view','MultiUploadController::_consturct');
$routes->post('/upload_view','FileUploadController::index');

$routes->match(['get','post'],'/department/add','DepartmentController::create');
$routes->get('/department/view','DepartmentController::view');
$routes->match(['get','post'],'/department/edit/(:num)','DepartmentController::edit/$1');
$routes->get('/department/delete/(:num)','DepartmentController::delete/$1');

$routes->match(['get','post'],'/designation/add','DesignationController::create');
$routes->get('/designation/view','DesignationController::view');
$routes->get('/designation/delete/(:num)','DesignationController::delete/$1');
$routes->match(['get','post'],'/designation/edit/(:num)','DesignationController::edit/$1');

$routes->match(['get','post'],'/employee/add','EmployeeController::create');
$routes->match(['get','post'],'/employee/view','EmployeeController::view');
$routes->match(['get','post'],'/employee/edit/(:num)','EmployeeController::edit/$1');
$routes->get('/employee/delete/(:num)','EmployeeController::delete/$1');

$routes->match(['get','post'],'/user_management/user_category/add','UserCategoryController::user_category_add');
$routes->match(['get','post'],'/user_management/user_category/view','UserCategoryController::user_category_view');
$routes->match(['get','post'],'/user_management/user_category/edit/(:num)','UserCategoryController::user_category_edit/$1');
$routes->match(['get','post'],'/user_management/user_category/delete/(:num)','UserCategoryController::user_category_delete/$1');

$routes->match(['get','post'],'/user_management/operations_list/view','OperationsListController::operations_list_view');
$routes->match(['get','post'],'/user_management/operations_list/add','OperationsListController::operations_list_add');
$routes->match(['get','post'],'/user_management/operations_list/edit/(:num)','OperationsListController::operations_list_edit/$1');
$routes->match(['get','post'],'/user_management/operations_list/delete/(:num)','OperationsListController::operations_list_delete/$1');

$routes->match(['get','post'],'/attendance/view','AttendanceController::view');
$routes->match(['get','post'],'/attendance/add','AttendanceController::create');



/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
