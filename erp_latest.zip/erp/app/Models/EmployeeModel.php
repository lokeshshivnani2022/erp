<?php

namespace App\Models;

use CodeIgniter\Model;

class EmployeeModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'employee';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'id',
        'emp_id',
        'first_name',
        'middle_name',
        'last_name',
        'dob',
        'gender',
        'father_name',
        'mother_name',
        'email',
        'city',
        'state',
        'country',
        'department',
        'designation',
        'zip_code',
        'current_address',
        'permanent_address',
        'mobile_number',
        'alternate_mobile_number',
        'bio',
        'job_title',
        'company_name',
        'job_start_date',
        'job_end_date',
        'job_role_experience_description',
        'marks_obtained_in_10th',
        'upload_10th_marksheet',
        'marks_obtained_in_12th',
        'upload_12th_marksheet',
        'highest_qualification',
        'upload_marksheet',
        'bank_name',
        'account_number',
        'ifsc_code',
        'upload_bank_passbook',
        'aadhar_number',
        'upload_front_side_of_aadhar_card',
        'upload_back_side_of_aadhar_card',
        'pan_number',
        'upload_pan_card_image',
        'password'
    ];

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function getRecords(){
        return $this->orderBy('id','desc')->findAll();
   }

   public function getRow($id){
       //select * from books where id==$id
       return $this->where('id',$id)->first();
   }
}
