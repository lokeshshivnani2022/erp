<?php

namespace App\Models;

use CodeIgniter\Model;

class OperationsListModel extends Model
{
    protected $table            = 'operations_list';    
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields    = ['id','user_category','operation','read','write','update','delete'];

    public function getRecords()
   {
        return $this->select('user_category.title,operations_list.*')->join('user_category','user_category.id=operations_list.id','left')->orderBy('user_category.id','desc')->findAll();
    }
   public function getRow($id)
   {
       //select * from books where id==$id
       return $this->where('id',$id)->first();
    }
}
?>