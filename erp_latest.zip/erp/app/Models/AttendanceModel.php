<?php
namespace App\Models;

use CodeIgniter\Model;

class AttendanceModel extends Model{
    protected $table = 'attendance';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields=['id','employee_id','attendance','remark','attendance_date'];

    public function getRecords(){
         return $this->orderBy('id','desc')->findAll();
    }

    public function getRow($id){
        //select * from books where id==$id
        return $this->where('id',$id)->first();
    }

}
?>