<?php
namespace App\Models;

use CodeIgniter\Model;

class DesignationModel extends Model{
    protected $primaryKey       = 'deg_id';
    protected $useAutoIncrement = true;
    protected $table = 'designation';
    protected $allowedFields=['deg_id','deg_name','dep_id'];

    public function getRecords(){
         return $this->select('department.dep_name,designation.*')->join('department','department.dep_id=designation.dep_id','left')->orderBy('deg_id','desc')->findAll();
    }

    public function getRow($deg_id){
        //select * from books where id==$id
        return $this->where('deg_id',$deg_id)->first();
    }

}
?>