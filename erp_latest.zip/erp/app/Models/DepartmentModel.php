<?php
namespace App\Models;

use CodeIgniter\Model;

class DepartmentModel extends Model{
    protected $table = 'department';
    protected $primaryKey       = 'dep_id';
    protected $useAutoIncrement = true;
    protected $allowedFields=['dep_id','dep_name'];

    public function getRecords(){
         return $this->orderBy('dep_id','desc')->findAll();
    }

    public function getRow($dep_id){
        //select * from books where id==$id
        return $this->where('dep_id',$dep_id)->first();
    }

}
?>