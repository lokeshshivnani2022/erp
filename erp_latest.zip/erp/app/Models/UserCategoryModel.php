<?php

namespace App\Models;

use CodeIgniter\Model;

class UserCategoryModel extends Model
{
    protected $table            = 'user_category';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields    = ['id','title'];

    public function getRecords(){
        return $this->orderBy('id','desc')->findAll();
   }

   public function getRow($id){
       //select * from books where id==$id
       return $this->where('id',$id)->first();
   }
}
?>